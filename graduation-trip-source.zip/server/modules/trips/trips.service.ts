import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { eq, inArray } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';

import {
  trips,
  members,
  itineraryItems,
  expenses,
  expenseShares,
  todos,
  groups,
  groupMembers,
} from '@server/database/schema';
import type {
  Trip,
  TripDetail,
  Member,
  ItineraryItem,
  Expense,
  Todo,
  Group,
} from '@shared/api.interface';
import type { CreateTripRequest, UpdateTripRequest } from '@shared/api.interface';

@Injectable()
export class TripsService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async findAll(): Promise<Trip[]> {
    const rows = await this.db.select().from(trips).orderBy(trips.createdAt);
    return rows.map((row) => ({
      id: row.id,
      name: row.name,
      destination: row.destination,
      startDate: row.startDate,
      endDate: row.endDate,
      budgetPerPerson: Number(row.budgetPerPerson),
    }));
  }

  async findOne(id: string): Promise<TripDetail> {
    const tripRows = await this.db.select().from(trips).where(eq(trips.id, id));
    if (tripRows.length === 0) {
      throw new NotFoundException('旅程不存在');
    }
    const tripRow = tripRows[0];

    const [memberRows, itineraryRows, expenseRows, todoRows, groupRows] =
      await Promise.all([
        this.db
          .select()
          .from(members)
          .where(eq(members.tripId, id))
          .orderBy(members.createdAt),
        this.db
          .select()
          .from(itineraryItems)
          .where(eq(itineraryItems.tripId, id))
          .orderBy(itineraryItems.dayIndex, itineraryItems.timeSlot),
        this.db
          .select()
          .from(expenses)
          .where(eq(expenses.tripId, id))
          .orderBy(expenses.createdAt),
        this.db
          .select()
          .from(todos)
          .where(eq(todos.tripId, id))
          .orderBy(todos.createdAt),
        this.db
          .select()
          .from(groups)
          .where(eq(groups.tripId, id))
          .orderBy(groups.createdAt),
      ]);

    const expenseIds = expenseRows.map((e) => e.id);
    const shareRows =
      expenseIds.length > 0
        ? await this.db
            .select()
            .from(expenseShares)
            .where(inArray(expenseShares.expenseId, expenseIds))
        : [];

    const groupIds = groupRows.map((g) => g.id);
    const groupMemberRows =
      groupIds.length > 0
        ? await this.db
            .select()
            .from(groupMembers)
            .where(inArray(groupMembers.groupId, groupIds))
        : [];

    const sharesByExpense = new Map<string, string[]>();
    for (const s of shareRows) {
      const arr = sharesByExpense.get(s.expenseId) ?? [];
      arr.push(s.memberId);
      sharesByExpense.set(s.expenseId, arr);
    }

    const membersByGroup = new Map<string, string[]>();
    for (const gm of groupMemberRows) {
      const arr = membersByGroup.get(gm.groupId) ?? [];
      arr.push(gm.memberId);
      membersByGroup.set(gm.groupId, arr);
    }

    const memberList: Member[] = memberRows.map((m) => ({
      id: m.id,
      tripId: m.tripId,
      name: m.name,
      destinationPreference: m.destinationPreference,
      budgetTier: m.budgetTier as Member['budgetTier'],
      notes: m.notes,
    }));

    const itineraryList: ItineraryItem[] = itineraryRows.map((i) => ({
      id: i.id,
      tripId: i.tripId,
      dayIndex: i.dayIndex,
      timeSlot: i.timeSlot,
      content: i.content,
      estimatedCost: Number(i.estimatedCost),
      category: i.category as ItineraryItem['category'],
      notes: i.notes,
    }));

    const expenseList: Expense[] = expenseRows.map((e) => ({
      id: e.id,
      tripId: e.tripId,
      item: e.item,
      amount: Number(e.amount),
      payerId: e.payerId,
      category: e.category as Expense['category'],
      note: e.note,
      shareMemberIds: sharesByExpense.get(e.id) ?? [],
    }));

    const todoList: Todo[] = todoRows.map((t) => ({
      id: t.id,
      tripId: t.tripId,
      content: t.content,
      completed: t.completed,
    }));

    const groupList: Group[] = groupRows.map((g) => ({
      id: g.id,
      tripId: g.tripId,
      groupName: g.groupName,
      memberIds: membersByGroup.get(g.id) ?? [],
    }));

    return {
      id: tripRow.id,
      name: tripRow.name,
      destination: tripRow.destination,
      startDate: tripRow.startDate,
      endDate: tripRow.endDate,
      budgetPerPerson: Number(tripRow.budgetPerPerson),
      members: memberList,
      itineraryItems: itineraryList,
      expenses: expenseList,
      todos: todoList,
      groups: groupList,
    };
  }

  async create(dto: CreateTripRequest): Promise<Trip> {
    const rows = await this.db
      .insert(trips)
      .values({
        name: dto.name,
        destination: dto.destination,
        startDate: dto.startDate,
        endDate: dto.endDate,
        budgetPerPerson: dto.budgetPerPerson.toString(),
      })
      .returning();
    const row = rows[0];
    return {
      id: row.id,
      name: row.name,
      destination: row.destination,
      startDate: row.startDate,
      endDate: row.endDate,
      budgetPerPerson: Number(row.budgetPerPerson),
    };
  }

  async update(id: string, dto: UpdateTripRequest): Promise<Trip> {
    const patch: Partial<typeof trips.$inferInsert> = {};
    if (dto.name !== undefined) patch.name = dto.name;
    if (dto.destination !== undefined) patch.destination = dto.destination;
    if (dto.startDate !== undefined) patch.startDate = dto.startDate;
    if (dto.endDate !== undefined) patch.endDate = dto.endDate;
    if (dto.budgetPerPerson !== undefined)
      patch.budgetPerPerson = dto.budgetPerPerson.toString();

    if (Object.keys(patch).length === 0) {
      const detail = await this.findOne(id);
      const { members: _m, itineraryItems: _i, expenses: _e, todos: _t, groups: _g, ...rest } =
        detail;
      return rest;
    }

    const rows = await this.db
      .update(trips)
      .set(patch)
      .where(eq(trips.id, id))
      .returning();
    if (rows.length === 0) {
      throw new NotFoundException('旅程不存在');
    }
    const row = rows[0];
    return {
      id: row.id,
      name: row.name,
      destination: row.destination,
      startDate: row.startDate,
      endDate: row.endDate,
      budgetPerPerson: Number(row.budgetPerPerson),
    };
  }

  async remove(id: string): Promise<{ success: boolean }> {
    const rows = await this.db
      .delete(trips)
      .where(eq(trips.id, id))
      .returning({ id: trips.id });
    if (rows.length === 0) {
      throw new NotFoundException('旅程不存在');
    }
    return { success: true };
  }
}
