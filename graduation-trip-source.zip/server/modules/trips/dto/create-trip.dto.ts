import { IsString, IsNumber, IsDateString } from 'class-validator';
import type { CreateTripRequest } from '@shared/api.interface';

export class CreateTripDto implements CreateTripRequest {
  @IsString()
  name!: string;

  @IsString()
  destination!: string;

  @IsDateString()
  startDate!: string;

  @IsDateString()
  endDate!: string;

  @IsNumber()
  budgetPerPerson!: number;
}
