import { IsString, IsNumber, IsDateString, IsOptional } from 'class-validator';
import type { UpdateTripRequest } from '@shared/api.interface';

export class UpdateTripDto implements UpdateTripRequest {
  @IsOptional()
  @IsString()
  name?: string;

  @IsOptional()
  @IsString()
  destination?: string;

  @IsOptional()
  @IsDateString()
  startDate?: string;

  @IsOptional()
  @IsDateString()
  endDate?: string;

  @IsOptional()
  @IsNumber()
  budgetPerPerson?: number;
}
