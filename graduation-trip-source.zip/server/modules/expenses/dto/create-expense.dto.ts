import { IsString, IsNumber, IsIn, IsArray } from 'class-validator';
import { Type } from 'class-transformer';
import type { CreateExpenseRequest, ExpenseCategory } from '@shared/api.interface';

const CATEGORIES: ExpenseCategory[] = [
  'transportation',
  'accommodation',
  'food',
  'attraction',
  'shopping',
  'other',
];

export class CreateExpenseDto implements CreateExpenseRequest {
  @IsString()
  tripId!: string;

  @IsString()
  item!: string;

  @IsNumber()
  amount!: number;

  @IsString()
  payerId!: string;

  @IsString()
  @IsIn(CATEGORIES)
  @Type(() => String)
  category!: ExpenseCategory;

  @IsString()
  note!: string;

  @IsArray()
  @IsString({ each: true })
  @Type(() => String)
  shareMemberIds!: string[];
}
