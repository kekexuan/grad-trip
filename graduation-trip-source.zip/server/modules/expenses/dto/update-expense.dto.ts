import { IsString, IsNumber, IsIn, IsArray, IsOptional } from 'class-validator';
import { Type } from 'class-transformer';
import type { UpdateExpenseRequest, ExpenseCategory } from '@shared/api.interface';

const CATEGORIES: ExpenseCategory[] = [
  'transportation',
  'accommodation',
  'food',
  'attraction',
  'shopping',
  'other',
];

export class UpdateExpenseDto implements UpdateExpenseRequest {
  @IsOptional()
  @IsString()
  item?: string;

  @IsOptional()
  @IsNumber()
  amount?: number;

  @IsOptional()
  @IsString()
  payerId?: string;

  @IsOptional()
  @IsString()
  @IsIn(CATEGORIES)
  @Type(() => String)
  category?: ExpenseCategory;

  @IsOptional()
  @IsString()
  note?: string;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  @Type(() => String)
  shareMemberIds?: string[];
}
