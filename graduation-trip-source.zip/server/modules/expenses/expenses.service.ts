import {
  Inject,
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { eq, inArray } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';

import { expenses, expenseShares, members } from '@server/database/schema';
import type {
  Expense,
  ExpenseSummary,
  CategoryCost,
  MemberBalance,
  SettlementTransfer,
} from '@shared/api.interface';
import type { CreateExpenseRequest, UpdateExpenseRequest } from '@shared/api.interface';

const CATEGORY_LABELS: Record<string, string> = {
  transportation: '交通',
  accommodation: '住宿',
  food: '餐饮',
  attraction: '景点',
  shopping: '购物',
  other: '其他',
};

@Injectable()
export class ExpensesService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async findByTrip(tripId: string): Promise<Expense[]> {
    const expenseRows = await this.db
      .select()
      .from(expenses)
      .where(eq(expenses.tripId, tripId))
      .orderBy(expenses.createdAt);

    const expenseIds = expenseRows.map((e) => e.id);
    const shareRows =
      expenseIds.length > 0
        ? await this.db
            .select()
            .from(expenseShares)
            .where(inArray(expenseShares.expenseId, expenseIds))
        : [];

    const sharesByExpense = new Map<string, string[]>();
    for (const s of shareRows) {
      const arr = sharesByExpense.get(s.expenseId) ?? [];
      arr.push(s.memberId);
      sharesByExpense.set(s.expenseId, arr);
    }

    return expenseRows.map((row) => ({
      id: row.id,
      tripId: row.tripId,
      item: row.item,
      amount: Number(row.amount),
      payerId: row.payerId,
      category: row.category as Expense['category'],
      note: row.note,
      shareMemberIds: sharesByExpense.get(row.id) ?? [],
    }));
  }

  async getSummary(tripId: string): Promise<ExpenseSummary> {
    const expenseList = await this.findByTrip(tripId);
    const memberRows = await this.db
      .select()
      .from(members)
      .where(eq(members.tripId, tripId));

    const memberMap = new Map<string, string>();
    for (const m of memberRows) {
      memberMap.set(m.id, m.name);
    }

    const totalAmount = expenseList.reduce(
      (sum: number, e: Expense) => sum + e.amount,
      0,
    );

    const byCategory = new Map<string, number>();
    for (const e of expenseList) {
      byCategory.set(e.category, (byCategory.get(e.category) ?? 0) + e.amount);
    }

    const costByCategory: CategoryCost[] = Array.from(byCategory.entries()).map(
      ([category, amount]) => ({
        category,
        categoryLabel: CATEGORY_LABELS[category] ?? category,
        amount,
      }),
    );

    // Calculate member balances
    const paidMap = new Map<string, number>();
    const shouldPayMap = new Map<string, number>();

    for (const m of memberRows) {
      paidMap.set(m.id, 0);
      shouldPayMap.set(m.id, 0);
    }

    for (const e of expenseList) {
      paidMap.set(e.payerId, (paidMap.get(e.payerId) ?? 0) + e.amount);

      const shareCount = e.shareMemberIds.length;
      if (shareCount > 0) {
        const perShare = e.amount / shareCount;
        for (const memberId of e.shareMemberIds) {
          shouldPayMap.set(
            memberId,
            (shouldPayMap.get(memberId) ?? 0) + perShare,
          );
        }
      }
    }

    const memberBalances: MemberBalance[] = memberRows.map((m) => {
      const paid = paidMap.get(m.id) ?? 0;
      const shouldPay = shouldPayMap.get(m.id) ?? 0;
      return {
        memberId: m.id,
        memberName: m.name,
        paid: Math.round(paid * 100) / 100,
        shouldPay: Math.round(shouldPay * 100) / 100,
        netBalance: Math.round((paid - shouldPay) * 100) / 100,
      };
    });

    // Greedy settlement algorithm
    const creditors = memberBalances
      .filter((b) => b.netBalance > 0.01)
      .sort((a, b) => b.netBalance - a.netBalance)
      .map((b) => ({ ...b, remaining: b.netBalance }));
    const debtors = memberBalances
      .filter((b) => b.netBalance < -0.01)
      .sort((a, b) => a.netBalance - b.netBalance)
      .map((b) => ({ ...b, remaining: -b.netBalance }));

    const settlementPlan: SettlementTransfer[] = [];
    let i = 0;
    let j = 0;

    while (i < creditors.length && j < debtors.length) {
      const amount = Math.min(creditors[i].remaining, debtors[j].remaining);
      if (amount > 0.01) {
        settlementPlan.push({
          fromMemberId: debtors[j].memberId,
          fromMemberName: debtors[j].memberName,
          toMemberId: creditors[i].memberId,
          toMemberName: creditors[i].memberName,
          amount: Math.round(amount * 100) / 100,
        });
      }
      creditors[i].remaining -= amount;
      debtors[j].remaining -= amount;
      if (creditors[i].remaining < 0.01) i++;
      if (debtors[j].remaining < 0.01) j++;
    }

    return {
      totalAmount,
      costByCategory,
      memberBalances,
      settlementPlan,
    };
  }

  async create(dto: CreateExpenseRequest): Promise<Expense> {
    if (dto.shareMemberIds.length === 0) {
      throw new BadRequestException('分摊成员不能为空');
    }

    const shareAmount = dto.amount / dto.shareMemberIds.length;

    return this.db.transaction(async (tx) => {
      const expenseRows = await tx
        .insert(expenses)
        .values({
          tripId: dto.tripId,
          item: dto.item,
          amount: dto.amount.toString(),
          payerId: dto.payerId,
          category: dto.category,
          note: dto.note,
        })
        .returning();

      const expenseRow = expenseRows[0];

      await tx.insert(expenseShares).values(
        dto.shareMemberIds.map((memberId) => ({
          expenseId: expenseRow.id,
          memberId,
          amount: shareAmount.toString(),
        })),
      );

      return {
        id: expenseRow.id,
        tripId: expenseRow.tripId,
        item: expenseRow.item,
        amount: Number(expenseRow.amount),
        payerId: expenseRow.payerId,
        category: expenseRow.category as Expense['category'],
        note: expenseRow.note,
        shareMemberIds: [...dto.shareMemberIds],
      };
    });
  }

  async update(id: string, dto: UpdateExpenseRequest): Promise<Expense> {
    return this.db.transaction(async (tx) => {
      // Check expense exists
      const existingRows = await tx
        .select()
        .from(expenses)
        .where(eq(expenses.id, id));
      if (existingRows.length === 0) {
        throw new NotFoundException('支出不存在');
      }

      const patch: Partial<typeof expenses.$inferInsert> = {};
      if (dto.item !== undefined) patch.item = dto.item;
      if (dto.amount !== undefined) patch.amount = dto.amount.toString();
      if (dto.payerId !== undefined) patch.payerId = dto.payerId;
      if (dto.category !== undefined) patch.category = dto.category;
      if (dto.note !== undefined) patch.note = dto.note;

      let updatedExpenseId = id;
      if (Object.keys(patch).length > 0) {
        const rows = await tx
          .update(expenses)
          .set(patch)
          .where(eq(expenses.id, id))
          .returning();
        updatedExpenseId = rows[0].id;
      }

      // Determine final amount and shareMemberIds
      const finalAmount =
        dto.amount !== undefined ? dto.amount : Number(existingRows[0].amount);
      let finalShareMemberIds = dto.shareMemberIds;

      if (finalShareMemberIds === undefined) {
        const existingShares = await tx
          .select()
          .from(expenseShares)
          .where(eq(expenseShares.expenseId, id));
        finalShareMemberIds = existingShares.map((s) => s.memberId);
      } else if (finalShareMemberIds.length === 0) {
        throw new BadRequestException('分摊成员不能为空');
      }

      if (dto.shareMemberIds !== undefined || dto.amount !== undefined) {
        // Delete old shares and insert new ones
        await tx.delete(expenseShares).where(eq(expenseShares.expenseId, id));
        const shareAmount = finalAmount / finalShareMemberIds.length;
        await tx.insert(expenseShares).values(
          finalShareMemberIds.map((memberId) => ({
            expenseId: id,
            memberId,
            amount: shareAmount.toString(),
          })),
        );
      }

      const finalRows = await tx
        .select()
        .from(expenses)
        .where(eq(expenses.id, updatedExpenseId));
      const finalRow = finalRows[0];

      return {
        id: finalRow.id,
        tripId: finalRow.tripId,
        item: finalRow.item,
        amount: Number(finalRow.amount),
        payerId: finalRow.payerId,
        category: finalRow.category as Expense['category'],
        note: finalRow.note,
        shareMemberIds: finalShareMemberIds,
      };
    });
  }

  async remove(id: string): Promise<{ success: boolean }> {
    const rows = await this.db
      .delete(expenses)
      .where(eq(expenses.id, id))
      .returning({ id: expenses.id });
    if (rows.length === 0) {
      throw new NotFoundException('支出不存在');
    }
    return { success: true };
  }
}
