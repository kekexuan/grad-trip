import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Param,
  Body,
  Query,
} from '@nestjs/common';
import { ExpensesService } from './expenses.service';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { UpdateExpenseDto } from './dto/update-expense.dto';
import type { Expense, ExpenseSummary } from '@shared/api.interface';

@Controller('api/expenses')
export class ExpensesController {
  constructor(private readonly expensesService: ExpensesService) {}

  @Get('summary')
  async getSummary(@Query('tripId') tripId: string): Promise<ExpenseSummary> {
    return this.expensesService.getSummary(tripId);
  }

  @Get()
  async findByTrip(@Query('tripId') tripId: string): Promise<Expense[]> {
    return this.expensesService.findByTrip(tripId);
  }

  @Post()
  async create(@Body() dto: CreateExpenseDto): Promise<Expense> {
    return this.expensesService.create(dto);
  }

  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateExpenseDto,
  ): Promise<Expense> {
    return this.expensesService.update(id, dto);
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<{ success: boolean }> {
    return this.expensesService.remove(id);
  }
}
