import { IsString } from 'class-validator';
import type { CreateTodoRequest } from '@shared/api.interface';

export class CreateTodoDto implements CreateTodoRequest {
  @IsString()
  tripId!: string;

  @IsString()
  content!: string;
}
