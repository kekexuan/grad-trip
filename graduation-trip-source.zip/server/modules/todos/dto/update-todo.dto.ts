import { IsString, IsBoolean, IsOptional } from 'class-validator';
import type { UpdateTodoRequest } from '@shared/api.interface';

export class UpdateTodoDto implements UpdateTodoRequest {
  @IsOptional()
  @IsString()
  content?: string;

  @IsOptional()
  @IsBoolean()
  completed?: boolean;
}
