import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { eq } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';

import { todos } from '@server/database/schema';
import type { Todo } from '@shared/api.interface';
import type { CreateTodoRequest, UpdateTodoRequest } from '@shared/api.interface';

@Injectable()
export class TodosService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async findByTrip(tripId: string): Promise<Todo[]> {
    const rows = await this.db
      .select()
      .from(todos)
      .where(eq(todos.tripId, tripId))
      .orderBy(todos.createdAt);
    return rows.map((row) => ({
      id: row.id,
      tripId: row.tripId,
      content: row.content,
      completed: row.completed,
    }));
  }

  async create(dto: CreateTodoRequest): Promise<Todo> {
    const rows = await this.db
      .insert(todos)
      .values({
        tripId: dto.tripId,
        content: dto.content,
      })
      .returning();
    const row = rows[0];
    return {
      id: row.id,
      tripId: row.tripId,
      content: row.content,
      completed: row.completed,
    };
  }

  async update(id: string, dto: UpdateTodoRequest): Promise<Todo> {
    const patch: Partial<typeof todos.$inferInsert> = {};
    if (dto.content !== undefined) patch.content = dto.content;
    if (dto.completed !== undefined) patch.completed = dto.completed;

    if (Object.keys(patch).length === 0) {
      const rows = await this.db.select().from(todos).where(eq(todos.id, id));
      if (rows.length === 0) throw new NotFoundException('待办不存在');
      const row = rows[0];
      return {
        id: row.id,
        tripId: row.tripId,
        content: row.content,
        completed: row.completed,
      };
    }

    const rows = await this.db
      .update(todos)
      .set(patch)
      .where(eq(todos.id, id))
      .returning();
    if (rows.length === 0) {
      throw new NotFoundException('待办不存在');
    }
    const row = rows[0];
    return {
      id: row.id,
      tripId: row.tripId,
      content: row.content,
      completed: row.completed,
    };
  }

  async remove(id: string): Promise<{ success: boolean }> {
    const rows = await this.db
      .delete(todos)
      .where(eq(todos.id, id))
      .returning({ id: todos.id });
    if (rows.length === 0) {
      throw new NotFoundException('待办不存在');
    }
    return { success: true };
  }
}
