import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Param,
  Body,
  Query,
} from '@nestjs/common';
import { MembersService } from './members.service';
import { CreateMemberDto } from './dto/create-member.dto';
import { UpdateMemberDto } from './dto/update-member.dto';
import type { Member } from '@shared/api.interface';

@Controller('api/members')
export class MembersController {
  constructor(private readonly membersService: MembersService) {}

  @Get()
  async findByTrip(@Query('tripId') tripId: string): Promise<Member[]> {
    return this.membersService.findByTrip(tripId);
  }

  @Post()
  async create(@Body() dto: CreateMemberDto): Promise<Member> {
    return this.membersService.create(dto);
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() dto: UpdateMemberDto): Promise<Member> {
    return this.membersService.update(id, dto);
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<{ success: boolean }> {
    return this.membersService.remove(id);
  }
}
