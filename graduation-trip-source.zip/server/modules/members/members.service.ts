import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { eq } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';

import { members } from '@server/database/schema';
import type { Member } from '@shared/api.interface';
import type { CreateMemberRequest, UpdateMemberRequest } from '@shared/api.interface';

@Injectable()
export class MembersService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async findByTrip(tripId: string): Promise<Member[]> {
    const rows = await this.db
      .select()
      .from(members)
      .where(eq(members.tripId, tripId))
      .orderBy(members.createdAt);
    return rows.map((row) => ({
      id: row.id,
      tripId: row.tripId,
      name: row.name,
      destinationPreference: row.destinationPreference,
      budgetTier: row.budgetTier as Member['budgetTier'],
      notes: row.notes,
    }));
  }

  async create(dto: CreateMemberRequest): Promise<Member> {
    const rows = await this.db
      .insert(members)
      .values({
        tripId: dto.tripId,
        name: dto.name,
        destinationPreference: dto.destinationPreference,
        budgetTier: dto.budgetTier,
        notes: dto.notes,
      })
      .returning();
    const row = rows[0];
    return {
      id: row.id,
      tripId: row.tripId,
      name: row.name,
      destinationPreference: row.destinationPreference,
      budgetTier: row.budgetTier as Member['budgetTier'],
      notes: row.notes,
    };
  }

  async update(id: string, dto: UpdateMemberRequest): Promise<Member> {
    const patch: Partial<typeof members.$inferInsert> = {};
    if (dto.name !== undefined) patch.name = dto.name;
    if (dto.destinationPreference !== undefined)
      patch.destinationPreference = dto.destinationPreference;
    if (dto.budgetTier !== undefined) patch.budgetTier = dto.budgetTier;
    if (dto.notes !== undefined) patch.notes = dto.notes;

    if (Object.keys(patch).length === 0) {
      const rows = await this.db.select().from(members).where(eq(members.id, id));
      if (rows.length === 0) throw new NotFoundException('成员不存在');
      const row = rows[0];
      return {
        id: row.id,
        tripId: row.tripId,
        name: row.name,
        destinationPreference: row.destinationPreference,
        budgetTier: row.budgetTier as Member['budgetTier'],
        notes: row.notes,
      };
    }

    const rows = await this.db
      .update(members)
      .set(patch)
      .where(eq(members.id, id))
      .returning();
    if (rows.length === 0) {
      throw new NotFoundException('成员不存在');
    }
    const row = rows[0];
    return {
      id: row.id,
      tripId: row.tripId,
      name: row.name,
      destinationPreference: row.destinationPreference,
      budgetTier: row.budgetTier as Member['budgetTier'],
      notes: row.notes,
    };
  }

  async remove(id: string): Promise<{ success: boolean }> {
    const rows = await this.db
      .delete(members)
      .where(eq(members.id, id))
      .returning({ id: members.id });
    if (rows.length === 0) {
      throw new NotFoundException('成员不存在');
    }
    return { success: true };
  }
}
