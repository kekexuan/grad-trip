import { IsString, IsIn, IsOptional } from 'class-validator';
import { Type } from 'class-transformer';
import type { UpdateMemberRequest, BudgetTier } from '@shared/api.interface';

export class UpdateMemberDto implements UpdateMemberRequest {
  @IsOptional()
  @IsString()
  name?: string;

  @IsOptional()
  @IsString()
  destinationPreference?: string;

  @IsOptional()
  @IsString()
  @IsIn(['economy', 'standard', 'premium'])
  @Type(() => String)
  budgetTier?: BudgetTier;

  @IsOptional()
  @IsString()
  notes?: string;
}
