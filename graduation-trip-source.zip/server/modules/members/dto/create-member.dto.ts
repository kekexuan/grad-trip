import { IsString, IsIn } from 'class-validator';
import { Type } from 'class-transformer';
import type { CreateMemberRequest, BudgetTier } from '@shared/api.interface';

export class CreateMemberDto implements CreateMemberRequest {
  @IsString()
  tripId!: string;

  @IsString()
  name!: string;

  @IsString()
  destinationPreference!: string;

  @IsString()
  @IsIn(['economy', 'standard', 'premium'])
  @Type(() => String)
  budgetTier!: BudgetTier;

  @IsString()
  notes!: string;
}
