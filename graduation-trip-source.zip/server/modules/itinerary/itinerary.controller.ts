import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Param,
  Body,
  Query,
} from '@nestjs/common';
import { ItineraryService } from './itinerary.service';
import { CreateItineraryItemDto } from './dto/create-itinerary-item.dto';
import { UpdateItineraryItemDto } from './dto/update-itinerary-item.dto';
import type { ItineraryItem, ItinerarySummary } from '@shared/api.interface';

@Controller('api/itinerary')
export class ItineraryController {
  constructor(private readonly itineraryService: ItineraryService) {}

  @Get('summary')
  async getSummary(@Query('tripId') tripId: string): Promise<ItinerarySummary> {
    return this.itineraryService.getSummary(tripId);
  }

  @Get()
  async findByTrip(@Query('tripId') tripId: string): Promise<ItineraryItem[]> {
    return this.itineraryService.findByTrip(tripId);
  }

  @Post()
  async create(@Body() dto: CreateItineraryItemDto): Promise<ItineraryItem> {
    return this.itineraryService.create(dto);
  }

  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateItineraryItemDto,
  ): Promise<ItineraryItem> {
    return this.itineraryService.update(id, dto);
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<{ success: boolean }> {
    return this.itineraryService.remove(id);
  }
}
