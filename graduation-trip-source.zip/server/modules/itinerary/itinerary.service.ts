import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { eq } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';

import { itineraryItems } from '@server/database/schema';
import type { ItineraryItem, ItinerarySummary, CategoryCost } from '@shared/api.interface';
import type {
  CreateItineraryItemRequest,
  UpdateItineraryItemRequest,
} from '@shared/api.interface';

const CATEGORY_LABELS: Record<string, string> = {
  transportation: '交通',
  accommodation: '住宿',
  food: '餐饮',
  attraction: '景点',
  shopping: '购物',
  other: '其他',
};

@Injectable()
export class ItineraryService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async findByTrip(tripId: string): Promise<ItineraryItem[]> {
    const rows = await this.db
      .select()
      .from(itineraryItems)
      .where(eq(itineraryItems.tripId, tripId))
      .orderBy(itineraryItems.dayIndex, itineraryItems.timeSlot);
    return rows.map((row) => ({
      id: row.id,
      tripId: row.tripId,
      dayIndex: row.dayIndex,
      timeSlot: row.timeSlot,
      content: row.content,
      estimatedCost: Number(row.estimatedCost),
      category: row.category as ItineraryItem['category'],
      notes: row.notes,
    }));
  }

  async getSummary(tripId: string): Promise<ItinerarySummary> {
    const items = await this.findByTrip(tripId);
    const totalCost = items.reduce((sum: number, item: ItineraryItem) => sum + item.estimatedCost, 0);
    const dayCount = items.length > 0 ? Math.max(...items.map((i: ItineraryItem) => i.dayIndex)) : 0;

    const byCategory = new Map<string, number>();
    for (const item of items) {
      byCategory.set(item.category, (byCategory.get(item.category) ?? 0) + item.estimatedCost);
    }

    const costByCategory: CategoryCost[] = Array.from(byCategory.entries()).map(
      ([category, amount]) => ({
        category,
        categoryLabel: CATEGORY_LABELS[category] ?? category,
        amount,
      }),
    );

    return {
      totalCost,
      costByCategory,
      dayCount,
      itemCount: items.length,
    };
  }

  async create(dto: CreateItineraryItemRequest): Promise<ItineraryItem> {
    const rows = await this.db
      .insert(itineraryItems)
      .values({
        tripId: dto.tripId,
        dayIndex: dto.dayIndex,
        timeSlot: dto.timeSlot,
        content: dto.content,
        estimatedCost: dto.estimatedCost.toString(),
        category: dto.category,
        notes: dto.notes,
      })
      .returning();
    const row = rows[0];
    return {
      id: row.id,
      tripId: row.tripId,
      dayIndex: row.dayIndex,
      timeSlot: row.timeSlot,
      content: row.content,
      estimatedCost: Number(row.estimatedCost),
      category: row.category as ItineraryItem['category'],
      notes: row.notes,
    };
  }

  async update(id: string, dto: UpdateItineraryItemRequest): Promise<ItineraryItem> {
    const patch: Partial<typeof itineraryItems.$inferInsert> = {};
    if (dto.dayIndex !== undefined) patch.dayIndex = dto.dayIndex;
    if (dto.timeSlot !== undefined) patch.timeSlot = dto.timeSlot;
    if (dto.content !== undefined) patch.content = dto.content;
    if (dto.estimatedCost !== undefined)
      patch.estimatedCost = dto.estimatedCost.toString();
    if (dto.category !== undefined) patch.category = dto.category;
    if (dto.notes !== undefined) patch.notes = dto.notes;

    if (Object.keys(patch).length === 0) {
      const rows = await this.db.select().from(itineraryItems).where(eq(itineraryItems.id, id));
      if (rows.length === 0) throw new NotFoundException('行程项目不存在');
      const row = rows[0];
      return {
        id: row.id,
        tripId: row.tripId,
        dayIndex: row.dayIndex,
        timeSlot: row.timeSlot,
        content: row.content,
        estimatedCost: Number(row.estimatedCost),
        category: row.category as ItineraryItem['category'],
        notes: row.notes,
      };
    }

    const rows = await this.db
      .update(itineraryItems)
      .set(patch)
      .where(eq(itineraryItems.id, id))
      .returning();
    if (rows.length === 0) {
      throw new NotFoundException('行程项目不存在');
    }
    const row = rows[0];
    return {
      id: row.id,
      tripId: row.tripId,
      dayIndex: row.dayIndex,
      timeSlot: row.timeSlot,
      content: row.content,
      estimatedCost: Number(row.estimatedCost),
      category: row.category as ItineraryItem['category'],
      notes: row.notes,
    };
  }

  async remove(id: string): Promise<{ success: boolean }> {
    const rows = await this.db
      .delete(itineraryItems)
      .where(eq(itineraryItems.id, id))
      .returning({ id: itineraryItems.id });
    if (rows.length === 0) {
      throw new NotFoundException('行程项目不存在');
    }
    return { success: true };
  }
}
