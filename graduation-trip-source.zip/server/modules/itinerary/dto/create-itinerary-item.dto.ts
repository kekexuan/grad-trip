import { IsString, IsNumber, IsIn } from 'class-validator';
import { Type } from 'class-transformer';
import type { CreateItineraryItemRequest, ItineraryCategory } from '@shared/api.interface';

const CATEGORIES: ItineraryCategory[] = [
  'transportation',
  'accommodation',
  'food',
  'attraction',
  'shopping',
  'other',
];

export class CreateItineraryItemDto implements CreateItineraryItemRequest {
  @IsString()
  tripId!: string;

  @IsNumber()
  dayIndex!: number;

  @IsString()
  timeSlot!: string;

  @IsString()
  content!: string;

  @IsNumber()
  estimatedCost!: number;

  @IsString()
  @IsIn(CATEGORIES)
  @Type(() => String)
  category!: ItineraryCategory;

  @IsString()
  notes!: string;
}
