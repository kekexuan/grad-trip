import { IsString, IsNumber, IsIn, IsOptional } from 'class-validator';
import { Type } from 'class-transformer';
import type { UpdateItineraryItemRequest, ItineraryCategory } from '@shared/api.interface';

const CATEGORIES: ItineraryCategory[] = [
  'transportation',
  'accommodation',
  'food',
  'attraction',
  'shopping',
  'other',
];

export class UpdateItineraryItemDto implements UpdateItineraryItemRequest {
  @IsOptional()
  @IsNumber()
  dayIndex?: number;

  @IsOptional()
  @IsString()
  timeSlot?: string;

  @IsOptional()
  @IsString()
  content?: string;

  @IsOptional()
  @IsNumber()
  estimatedCost?: number;

  @IsOptional()
  @IsString()
  @IsIn(CATEGORIES)
  @Type(() => String)
  category?: ItineraryCategory;

  @IsOptional()
  @IsString()
  notes?: string;
}
