import { IsString, IsNumber } from 'class-validator';
import type { SmartGroupRequest } from '@shared/api.interface';

export class SmartGroupDto implements SmartGroupRequest {
  @IsString()
  tripId!: string;

  @IsNumber()
  groupCount!: number;
}
