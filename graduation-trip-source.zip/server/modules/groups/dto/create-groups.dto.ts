import { IsString, IsArray, ValidateNested, ArrayMinSize } from 'class-validator';
import { Type } from 'class-transformer';
import type { CreateGroupsRequest } from '@shared/api.interface';

class GroupItemDto {
  @IsString()
  groupName!: string;

  @IsArray()
  @IsString({ each: true })
  memberIds!: string[];
}

export class CreateGroupsDto implements CreateGroupsRequest {
  @IsString()
  tripId!: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => GroupItemDto)
  @ArrayMinSize(1)
  groups!: Array<{ groupName: string; memberIds: string[] }>;
}
