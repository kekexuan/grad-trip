import { Controller, Get, Post, Body, Query } from '@nestjs/common';
import { GroupsService } from './groups.service';
import { CreateGroupsDto } from './dto/create-groups.dto';
import { SmartGroupDto } from './dto/smart-group.dto';
import type { Group, GroupSuggestion } from '@shared/api.interface';

@Controller('api/groups')
export class GroupsController {
  constructor(private readonly groupsService: GroupsService) {}

  @Get()
  async findByTrip(@Query('tripId') tripId: string): Promise<Group[]> {
    return this.groupsService.findByTrip(tripId);
  }

  @Post()
  async bulkCreate(@Body() dto: CreateGroupsDto): Promise<Group[]> {
    return this.groupsService.bulkCreate(dto);
  }

  @Post('smart')
  async smartGroup(@Body() dto: SmartGroupDto): Promise<GroupSuggestion[]> {
    return this.groupsService.smartGroup(dto.tripId, dto.groupCount);
  }
}
