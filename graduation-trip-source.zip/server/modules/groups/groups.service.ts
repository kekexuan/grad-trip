import {
  Inject,
  Injectable,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import { eq, inArray } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';

import { groups, groupMembers, members, trips } from '@server/database/schema';
import type { Group, GroupSuggestion, BudgetTier } from '@shared/api.interface';
import type { CreateGroupsRequest } from '@shared/api.interface';

const BUDGET_TIER_VALUES: Record<BudgetTier, number> = {
  economy: 1,
  standard: 2,
  premium: 3,
};

const BUDGET_TIER_MULTIPLIER: Record<BudgetTier, number> = {
  economy: 0.8,
  standard: 1.0,
  premium: 1.2,
};

const CHINESE_NUMERALS = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十'];

@Injectable()
export class GroupsService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async findByTrip(tripId: string): Promise<Group[]> {
    const groupRows = await this.db
      .select()
      .from(groups)
      .where(eq(groups.tripId, tripId))
      .orderBy(groups.createdAt);

    const groupIds = groupRows.map((g) => g.id);
    const memberRows =
      groupIds.length > 0
        ? await this.db
            .select()
            .from(groupMembers)
            .where(inArray(groupMembers.groupId, groupIds))
        : [];

    const membersByGroup = new Map<string, string[]>();
    for (const gm of memberRows) {
      const arr = membersByGroup.get(gm.groupId) ?? [];
      arr.push(gm.memberId);
      membersByGroup.set(gm.groupId, arr);
    }

    return groupRows.map((row) => ({
      id: row.id,
      tripId: row.tripId,
      groupName: row.groupName,
      memberIds: membersByGroup.get(row.id) ?? [],
    }));
  }

  async bulkCreate(dto: CreateGroupsRequest): Promise<Group[]> {
    if (dto.groups.length === 0) {
      throw new BadRequestException('分组不能为空');
    }

    return this.db.transaction(async (tx) => {
      // Delete existing groups for this trip
      const existingGroups = await tx
        .select({ id: groups.id })
        .from(groups)
        .where(eq(groups.tripId, dto.tripId));

      if (existingGroups.length > 0) {
        const ids = existingGroups.map((g) => g.id);
        await tx.delete(groupMembers).where(inArray(groupMembers.groupId, ids));
        await tx.delete(groups).where(inArray(groups.id, ids));
      }

      const result: Group[] = [];

      for (const g of dto.groups) {
        const inserted = await tx
          .insert(groups)
          .values({
            tripId: dto.tripId,
            groupName: g.groupName,
          })
          .returning();

        const groupRow = inserted[0];

        if (g.memberIds.length > 0) {
          await tx.insert(groupMembers).values(
            g.memberIds.map((memberId) => ({
              groupId: groupRow.id,
              memberId,
            })),
          );
        }

        result.push({
          id: groupRow.id,
          tripId: groupRow.tripId,
          groupName: groupRow.groupName,
          memberIds: [...g.memberIds],
        });
      }

      return result;
    });
  }

  async smartGroup(tripId: string, groupCount: number): Promise<GroupSuggestion[]> {
    if (groupCount < 1) {
      throw new BadRequestException('分组数量必须大于0');
    }

    // Get trip for budgetPerPerson
    const tripRows = await this.db.select().from(trips).where(eq(trips.id, tripId));
    if (tripRows.length === 0) {
      throw new NotFoundException('旅程不存在');
    }
    const budgetPerPerson = Number(tripRows[0].budgetPerPerson);

    // Get all members
    const memberRows = await this.db
      .select()
      .from(members)
      .where(eq(members.tripId, tripId))
      .orderBy(members.createdAt);

    if (memberRows.length === 0) {
      return [];
    }

    // Group by destination preference
    const byPreference = new Map<string, typeof memberRows>();
    for (const m of memberRows) {
      const pref = m.destinationPreference || '未指定';
      const arr = byPreference.get(pref) ?? [];
      arr.push(m);
      byPreference.set(pref, arr);
    }

    // Within each preference group, sort by budget tier (ascending)
    for (const [pref, arr] of byPreference) {
      arr.sort(
        (a, b) =>
          BUDGET_TIER_VALUES[(a.budgetTier as BudgetTier) ?? 'standard'] -
          BUDGET_TIER_VALUES[(b.budgetTier as BudgetTier) ?? 'standard'],
      );
      byPreference.set(pref, arr);
    }

    // Distribute members across groupCount groups using round-robin
    // to ensure budget balance, but keeping preference groups together as much as possible
    const finalGroups: typeof memberRows[] = Array.from(
      { length: groupCount },
      () => [],
    );

    // For each preference group, distribute members evenly across all groups
    let currentGroup = 0;
    const preferenceKeys = Array.from(byPreference.keys());

    for (const pref of preferenceKeys) {
      const prefMembers = byPreference.get(pref)!;
      // Distribute using serpentine (snake) pattern for better balance
      for (let i = 0; i < prefMembers.length; i++) {
        const targetIdx = currentGroup % groupCount;
        finalGroups[targetIdx].push(prefMembers[i]);
        currentGroup++;
      }
    }

    // Build result
    const result: GroupSuggestion[] = finalGroups.map((groupMembersArr, idx) => {
      const groupName =
        idx < CHINESE_NUMERALS.length
          ? `${CHINESE_NUMERALS[idx]}组`
          : `第${idx + 1}组`;

      const memberIds = groupMembersArr.map((m) => m.id);
      const memberNames = groupMembersArr.map((m) => m.name);

      let totalBudget = 0;
      for (const m of groupMembersArr) {
        const tier = (m.budgetTier as BudgetTier) ?? 'standard';
        totalBudget += budgetPerPerson * BUDGET_TIER_MULTIPLIER[tier];
      }
      const avgBudget =
        groupMembersArr.length > 0
          ? Math.round((totalBudget / groupMembersArr.length) * 100) / 100
          : 0;

      return {
        id: `suggestion-${idx + 1}`,
        groupName,
        memberIds,
        memberNames,
        avgBudget,
      };
    });

    return result;
  }
}
