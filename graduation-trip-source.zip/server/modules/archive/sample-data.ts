import type {
  CreateTripRequest,
  CreateMemberRequest,
  CreateItineraryItemRequest,
  CreateExpenseRequest,
  CreateTodoRequest,
} from '@shared/api.interface';

export const SAMPLE_TRIP: CreateTripRequest = {
  name: '大理毕业之旅',
  destination: '云南大理',
  startDate: '2025-06-15',
  endDate: '2025-06-20',
  budgetPerPerson: 3000,
};

export const SAMPLE_MEMBERS: Omit<CreateMemberRequest, 'tripId'>[] = [
  {
    name: '张小明',
    destinationPreference: '大理古城',
    budgetTier: 'standard',
    notes: '文艺青年，爱拍照',
  },
  {
    name: '李小红',
    destinationPreference: '洱海',
    budgetTier: 'premium',
    notes: '富二代，住好酒店',
  },
  {
    name: '王小强',
    destinationPreference: '苍山',
    budgetTier: 'economy',
    notes: '穷游党，能省则省',
  },
  {
    name: '赵小美',
    destinationPreference: '洱海',
    budgetTier: 'standard',
    notes: '吃货，到处找美食',
  },
  {
    name: '孙小鹏',
    destinationPreference: '大理古城',
    budgetTier: 'standard',
    notes: '摄影爱好者',
  },
  {
    name: '周小雨',
    destinationPreference: '苍山',
    budgetTier: 'economy',
    notes: '户外爱好者',
  },
  {
    name: '吴小天',
    destinationPreference: '洱海',
    budgetTier: 'premium',
    notes: '享受型玩家',
  },
  {
    name: '郑小丽',
    destinationPreference: '大理古城',
    budgetTier: 'economy',
    notes: '学生党预算紧',
  },
];

export const SAMPLE_ITINERARY: Omit<CreateItineraryItemRequest, 'tripId'>[] = [
  // Day 1
  { dayIndex: 1, timeSlot: '上午', content: '到达大理', estimatedCost: 0, category: 'transportation', notes: '飞机或高铁抵达' },
  { dayIndex: 1, timeSlot: '下午', content: '入住古城民宿', estimatedCost: 200, category: 'accommodation', notes: '古城内特色民宿' },
  { dayIndex: 1, timeSlot: '晚上', content: '古城夜游', estimatedCost: 50, category: 'attraction', notes: '逛五华楼、人民路' },
  // Day 2
  { dayIndex: 2, timeSlot: '上午', content: '环洱海骑行', estimatedCost: 150, category: 'attraction', notes: '租电动车环湖' },
  { dayIndex: 2, timeSlot: '中午', content: '双廊古镇午餐', estimatedCost: 80, category: 'food', notes: '海边餐厅' },
  { dayIndex: 2, timeSlot: '下午', content: '南诏风情岛', estimatedCost: 80, category: 'attraction', notes: '船票+门票' },
  { dayIndex: 2, timeSlot: '晚上', content: '大理古城晚餐', estimatedCost: 60, category: 'food', notes: '白族特色菜' },
  // Day 3
  { dayIndex: 3, timeSlot: '上午', content: '苍山索道', estimatedCost: 280, category: 'attraction', notes: '洗马潭大索道' },
  { dayIndex: 3, timeSlot: '中午', content: '寂照庵素斋', estimatedCost: 30, category: 'food', notes: '网红素斋' },
  { dayIndex: 3, timeSlot: '下午', content: '天龙八部影视城', estimatedCost: 60, category: 'attraction', notes: '古装打卡' },
  { dayIndex: 3, timeSlot: '晚上', content: '古城酒吧', estimatedCost: 100, category: 'other', notes: '红龙井酒吧街' },
  // Day 4
  { dayIndex: 4, timeSlot: '上午', content: '喜洲古镇', estimatedCost: 50, category: 'attraction', notes: '白族民居建筑群' },
  { dayIndex: 4, timeSlot: '中午', content: '海舌生态公园', estimatedCost: 20, category: 'attraction', notes: '洱海湿地公园' },
  { dayIndex: 4, timeSlot: '下午', content: '周城扎染体验', estimatedCost: 80, category: 'other', notes: '手工扎染DIY' },
  { dayIndex: 4, timeSlot: '晚上', content: '白族特色晚餐', estimatedCost: 100, category: 'food', notes: '大理古城特色餐厅' },
  // Day 5
  { dayIndex: 5, timeSlot: '上午', content: '返程采购', estimatedCost: 200, category: 'shopping', notes: '鲜花饼、乳扇等伴手礼' },
  { dayIndex: 5, timeSlot: '下午', content: '返程交通', estimatedCost: 0, category: 'transportation', notes: '机场/高铁站' },
];

// Indexes match SAMPLE_MEMBERS order for payer reference
const PAYER_INDEX: Record<string, number> = {
  '张小明': 0,
  '李小红': 1,
  '王小强': 2,
  '赵小美': 3,
  '孙小鹏': 4,
  '周小雨': 5,
  '吴小天': 6,
  '郑小丽': 7,
};

export interface SampleExpense {
  item: string;
  amount: number;
  payerName: string;
  category: 'transportation' | 'accommodation' | 'food' | 'attraction' | 'shopping' | 'other';
  note: string;
  shareMemberNames: string[];
}

export const SAMPLE_EXPENSES: SampleExpense[] = [
  {
    item: '民宿5晚',
    amount: 8000,
    payerName: '张小明',
    category: 'accommodation',
    note: '古城民宿，8人5晚',
    shareMemberNames: ['张小明', '李小红', '王小强', '赵小美', '孙小鹏', '周小雨', '吴小天', '郑小丽'],
  },
  {
    item: '环洱海租车',
    amount: 1200,
    payerName: '李小红',
    category: 'transportation',
    note: '两辆电动车，全天',
    shareMemberNames: ['张小明', '李小红', '王小强', '赵小美', '孙小鹏', '周小雨', '吴小天', '郑小丽'],
  },
  {
    item: '苍山套票',
    amount: 2240,
    payerName: '王小强',
    category: 'attraction',
    note: '索道+影视城联票',
    shareMemberNames: ['张小明', '李小红', '王小强', '赵小美', '孙小鹏', '周小雨', '吴小天', '郑小丽'],
  },
  {
    item: '第一晚聚餐',
    amount: 800,
    payerName: '赵小美',
    category: 'food',
    note: '大理古城白族菜',
    shareMemberNames: ['张小明', '李小红', '王小强', '赵小美', '孙小鹏', '周小雨', '吴小天', '郑小丽'],
  },
  {
    item: '酒吧消费',
    amount: 600,
    payerName: '孙小鹏',
    category: 'other',
    note: '古城红龙井酒吧',
    shareMemberNames: ['张小明', '李小红', '赵小美', '孙小鹏', '吴小天', '郑小丽'],
  },
  {
    item: '扎染体验',
    amount: 480,
    payerName: '周小雨',
    category: 'other',
    note: '周城扎染工坊',
    shareMemberNames: ['张小明', '李小红', '王小强', '赵小美', '孙小鹏', '周小雨', '吴小天', '郑小丽'],
  },
  {
    item: '采购伴手礼',
    amount: 500,
    payerName: '吴小天',
    category: 'shopping',
    note: '鲜花饼、乳扇',
    shareMemberNames: ['吴小天'],
  },
];

export const SAMPLE_TODOS: Array<{ content: string; completed: boolean }> = [
  { content: '订机票', completed: true },
  { content: '订民宿', completed: true },
  { content: '查当地天气', completed: false },
  { content: '准备防晒用品', completed: false },
  { content: '买旅游保险', completed: false },
  { content: '订苍山索道票', completed: false },
  { content: '租电动车', completed: false },
  { content: '做拍照攻略', completed: false },
];
