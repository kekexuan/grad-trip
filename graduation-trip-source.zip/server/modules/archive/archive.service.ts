import {
  Inject,
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { eq, inArray } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';

import {
  trips,
  members,
  itineraryItems,
  expenses,
  expenseShares,
  todos,
  groups,
  groupMembers,
} from '@server/database/schema';
import {
  SAMPLE_TRIP,
  SAMPLE_MEMBERS,
  SAMPLE_ITINERARY,
  SAMPLE_EXPENSES,
  SAMPLE_TODOS,
} from './sample-data';
import type {
  Trip,
  Member,
  ItineraryItem,
  Expense,
  Todo,
  Group,
  ExportArchive,
  ImportResult,
} from '@shared/api.interface';

@Injectable()
export class ArchiveService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async exportTrip(tripId: string): Promise<ExportArchive> {
    // Trip
    const tripRows = await this.db.select().from(trips).where(eq(trips.id, tripId));
    if (tripRows.length === 0) {
      throw new NotFoundException('旅程不存在');
    }
    const tripRow = tripRows[0];

    const trip: Trip = {
      id: tripRow.id,
      name: tripRow.name,
      destination: tripRow.destination,
      startDate: tripRow.startDate,
      endDate: tripRow.endDate,
      budgetPerPerson: Number(tripRow.budgetPerPerson),
    };

    // Members
    const memberRows = await this.db
      .select()
      .from(members)
      .where(eq(members.tripId, tripId))
      .orderBy(members.createdAt);
    const memberList: Member[] = memberRows.map((m) => ({
      id: m.id,
      tripId: m.tripId,
      name: m.name,
      destinationPreference: m.destinationPreference,
      budgetTier: m.budgetTier as Member['budgetTier'],
      notes: m.notes,
    }));

    // Itinerary
    const itineraryRows = await this.db
      .select()
      .from(itineraryItems)
      .where(eq(itineraryItems.tripId, tripId))
      .orderBy(itineraryItems.dayIndex, itineraryItems.timeSlot);
    const itineraryList: ItineraryItem[] = itineraryRows.map((i) => ({
      id: i.id,
      tripId: i.tripId,
      dayIndex: i.dayIndex,
      timeSlot: i.timeSlot,
      content: i.content,
      estimatedCost: Number(i.estimatedCost),
      category: i.category as ItineraryItem['category'],
      notes: i.notes,
    }));

    // Expenses + shares
    const expenseRows = await this.db
      .select()
      .from(expenses)
      .where(eq(expenses.tripId, tripId))
      .orderBy(expenses.createdAt);

    const expenseIds = expenseRows.map((e) => e.id);
    const shareRows =
      expenseIds.length > 0
        ? await this.db
            .select()
            .from(expenseShares)
            .where(inArray(expenseShares.expenseId, expenseIds))
        : [];

    const sharesByExpense = new Map<string, string[]>();
    for (const s of shareRows) {
      const arr = sharesByExpense.get(s.expenseId) ?? [];
      arr.push(s.memberId);
      sharesByExpense.set(s.expenseId, arr);
    }

    const expenseList: Expense[] = expenseRows.map((e) => ({
      id: e.id,
      tripId: e.tripId,
      item: e.item,
      amount: Number(e.amount),
      payerId: e.payerId,
      category: e.category as Expense['category'],
      note: e.note,
      shareMemberIds: sharesByExpense.get(e.id) ?? [],
    }));

    // Todos
    const todoRows = await this.db
      .select()
      .from(todos)
      .where(eq(todos.tripId, tripId))
      .orderBy(todos.createdAt);
    const todoList: Todo[] = todoRows.map((t) => ({
      id: t.id,
      tripId: t.tripId,
      content: t.content,
      completed: t.completed,
    }));

    // Groups + members
    const groupRows = await this.db
      .select()
      .from(groups)
      .where(eq(groups.tripId, tripId))
      .orderBy(groups.createdAt);

    const groupIds = groupRows.map((g) => g.id);
    const groupMemberRows =
      groupIds.length > 0
        ? await this.db
            .select()
            .from(groupMembers)
            .where(inArray(groupMembers.groupId, groupIds))
        : [];

    const membersByGroup = new Map<string, string[]>();
    for (const gm of groupMemberRows) {
      const arr = membersByGroup.get(gm.groupId) ?? [];
      arr.push(gm.memberId);
      membersByGroup.set(gm.groupId, arr);
    }

    const groupList: Group[] = groupRows.map((g) => ({
      id: g.id,
      tripId: g.tripId,
      groupName: g.groupName,
      memberIds: membersByGroup.get(g.id) ?? [],
    }));

    return {
      trip,
      members: memberList,
      itineraryItems: itineraryList,
      expenses: expenseList,
      todos: todoList,
      groups: groupList,
      version: '1.0',
    };
  }

  async importArchive(archive: ExportArchive): Promise<ImportResult> {
    if (!archive.trip) {
      throw new BadRequestException('存档数据不完整：缺少 trip');
    }

    return this.db.transaction(async (tx) => {
      // Create trip
      const tripRows = await tx
        .insert(trips)
        .values({
          name: archive.trip.name,
          destination: archive.trip.destination,
          startDate: archive.trip.startDate,
          endDate: archive.trip.endDate,
          budgetPerPerson: archive.trip.budgetPerPerson.toString(),
        })
        .returning();
      const newTripId = tripRows[0].id;

      // Create members and build id map
      const memberIdMap = new Map<string, string>();
      const createdMembers: Member[] = [];

      for (const m of archive.members ?? []) {
        const rows = await tx
          .insert(members)
          .values({
            tripId: newTripId,
            name: m.name,
            destinationPreference: m.destinationPreference,
            budgetTier: m.budgetTier,
            notes: m.notes,
          })
          .returning();
        memberIdMap.set(m.id, rows[0].id);
        createdMembers.push({
          id: rows[0].id,
          tripId: rows[0].tripId,
          name: rows[0].name,
          destinationPreference: rows[0].destinationPreference,
          budgetTier: rows[0].budgetTier as Member['budgetTier'],
          notes: rows[0].notes,
        });
      }

      // Create itinerary items
      const createdItineraryCount = (archive.itineraryItems ?? []).length;
      for (const item of archive.itineraryItems ?? []) {
        await tx.insert(itineraryItems).values({
          tripId: newTripId,
          dayIndex: item.dayIndex,
          timeSlot: item.timeSlot,
          content: item.content,
          estimatedCost: item.estimatedCost.toString(),
          category: item.category,
          notes: item.notes,
        });
      }

      // Create expenses + shares
      const createdExpensesCount = (archive.expenses ?? []).length;
      for (const exp of archive.expenses ?? []) {
        const newPayerId = memberIdMap.get(exp.payerId);
        if (!newPayerId) {
          throw new BadRequestException(`支出 ${exp.item} 的付款人不存在`);
        }

        const expRows = await tx
          .insert(expenses)
          .values({
            tripId: newTripId,
            item: exp.item,
            amount: exp.amount.toString(),
            payerId: newPayerId,
            category: exp.category,
            note: exp.note,
          })
          .returning();

        const shareMemberIds = exp.shareMemberIds
          .map((oldId) => memberIdMap.get(oldId))
          .filter((id): id is string => id !== undefined);

        if (shareMemberIds.length > 0) {
          const shareAmount = exp.amount / shareMemberIds.length;
          await tx.insert(expenseShares).values(
            shareMemberIds.map((memberId) => ({
              expenseId: expRows[0].id,
              memberId,
              amount: shareAmount.toString(),
            })),
          );
        }
      }

      // Create todos
      const createdTodosCount = (archive.todos ?? []).length;
      for (const todo of archive.todos ?? []) {
        await tx.insert(todos).values({
          tripId: newTripId,
          content: todo.content,
          completed: todo.completed,
        });
      }

      // Create groups + members
      const createdGroupsCount = (archive.groups ?? []).length;
      for (const g of archive.groups ?? []) {
        const groupRows = await tx
          .insert(groups)
          .values({
            tripId: newTripId,
            groupName: g.groupName,
          })
          .returning();

        const groupMemberIds = g.memberIds
          .map((oldId) => memberIdMap.get(oldId))
          .filter((id): id is string => id !== undefined);

        if (groupMemberIds.length > 0) {
          await tx.insert(groupMembers).values(
            groupMemberIds.map((memberId) => ({
              groupId: groupRows[0].id,
              memberId,
            })),
          );
        }
      }

      return {
        tripId: newTripId,
        membersCount: createdMembers.length,
        itineraryItemsCount: createdItineraryCount,
        expensesCount: createdExpensesCount,
        todosCount: createdTodosCount,
        groupsCount: createdGroupsCount,
      };
    });
  }

  async loadSampleData(): Promise<ImportResult> {
    return this.db.transaction(async (tx) => {
      // Create trip
      const tripRows = await tx
        .insert(trips)
        .values({
          name: SAMPLE_TRIP.name,
          destination: SAMPLE_TRIP.destination,
          startDate: SAMPLE_TRIP.startDate,
          endDate: SAMPLE_TRIP.endDate,
          budgetPerPerson: SAMPLE_TRIP.budgetPerPerson.toString(),
        })
        .returning();
      const tripId = tripRows[0].id;

      // Create members
      const memberIds: string[] = [];
      const memberNames: string[] = [];
      for (const m of SAMPLE_MEMBERS) {
        const rows = await tx
          .insert(members)
          .values({
            tripId,
            name: m.name,
            destinationPreference: m.destinationPreference,
            budgetTier: m.budgetTier,
            notes: m.notes,
          })
          .returning();
        memberIds.push(rows[0].id);
        memberNames.push(m.name);
      }

      // Build name -> id map
      const nameToId = new Map<string, string>();
      for (let i = 0; i < memberNames.length; i++) {
        nameToId.set(memberNames[i], memberIds[i]);
      }

      // Create itinerary
      for (const item of SAMPLE_ITINERARY) {
        await tx.insert(itineraryItems).values({
          tripId,
          dayIndex: item.dayIndex,
          timeSlot: item.timeSlot,
          content: item.content,
          estimatedCost: item.estimatedCost.toString(),
          category: item.category,
          notes: item.notes,
        });
      }

      // Create expenses + shares
      for (const exp of SAMPLE_EXPENSES) {
        const payerId = nameToId.get(exp.payerName);
        if (!payerId) continue;

        const expRows = await tx
          .insert(expenses)
          .values({
            tripId,
            item: exp.item,
            amount: exp.amount.toString(),
            payerId,
            category: exp.category,
            note: exp.note,
          })
          .returning();

        const shareIds = exp.shareMemberNames
          .map((name) => nameToId.get(name))
          .filter((id): id is string => id !== undefined);

        if (shareIds.length > 0) {
          const shareAmount = exp.amount / shareIds.length;
          await tx.insert(expenseShares).values(
            shareIds.map((memberId) => ({
              expenseId: expRows[0].id,
              memberId,
              amount: shareAmount.toString(),
            })),
          );
        }
      }

      // Create todos
      for (const todo of SAMPLE_TODOS) {
        await tx.insert(todos).values({
          tripId,
          content: todo.content,
          completed: todo.completed,
        });
      }

      // Create 2 groups based on smart grouping logic
      // Group by destination preference, balance budget tiers
      const membersWithTier = SAMPLE_MEMBERS.map((m, idx) => ({
        id: memberIds[idx],
        name: m.name,
        preference: m.destinationPreference,
        budgetTier: m.budgetTier,
      }));

      // Group by preference
      const byPref = new Map<string, typeof membersWithTier>();
      for (const m of membersWithTier) {
        const arr = byPref.get(m.preference) ?? [];
        arr.push(m);
        byPref.set(m.preference, arr);
      }

      // Sort each by budget tier
      const tierOrder = { economy: 0, standard: 1, premium: 2 } as const;
      for (const [pref, arr] of byPref) {
        arr.sort((a, b) => tierOrder[a.budgetTier] - tierOrder[b.budgetTier]);
        byPref.set(pref, arr);
      }

      // Distribute round-robin into 2 groups
      const group1: string[] = [];
      const group2: string[] = [];
      let flip = true;

      for (const pref of byPref.keys()) {
        const arr = byPref.get(pref)!;
        for (const m of arr) {
          if (flip) {
            group1.push(m.id);
          } else {
            group2.push(m.id);
          }
          flip = !flip;
        }
      }

      // Create groups
      const groupNames = ['一组', '二组'];
      const groupsArr = [group1, group2];

      for (let i = 0; i < 2; i++) {
        const gRows = await tx
          .insert(groups)
          .values({
            tripId,
            groupName: groupNames[i],
          })
          .returning();

        if (groupsArr[i].length > 0) {
          await tx.insert(groupMembers).values(
            groupsArr[i].map((memberId) => ({
              groupId: gRows[0].id,
              memberId,
            })),
          );
        }
      }

      return {
        tripId,
        membersCount: memberIds.length,
        itineraryItemsCount: SAMPLE_ITINERARY.length,
        expensesCount: SAMPLE_EXPENSES.length,
        todosCount: SAMPLE_TODOS.length,
        groupsCount: 2,
      };
    });
  }

  async clearAll(): Promise<void> {
    await this.db.delete(trips);
  }
}
