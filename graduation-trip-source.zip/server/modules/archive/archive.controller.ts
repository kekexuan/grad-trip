import { Controller, Get, Post, Param, Body, Delete } from '@nestjs/common';
import { ArchiveService } from './archive.service';
import type { ExportArchive, ImportResult } from '@shared/api.interface';

@Controller('api/archive')
export class ArchiveController {
  constructor(private readonly archiveService: ArchiveService) {}

  @Get('export/:tripId')
  async exportTrip(@Param('tripId') tripId: string): Promise<ExportArchive> {
    return this.archiveService.exportTrip(tripId);
  }

  @Post('import')
  async importArchive(@Body() archive: ExportArchive): Promise<ImportResult> {
    return this.archiveService.importArchive(archive);
  }

  @Post('sample')
  async loadSampleData(): Promise<ImportResult> {
    return this.archiveService.loadSampleData();
  }

  @Delete('all')
  async clearAll(): Promise<{ success: boolean }> {
    await this.archiveService.clearAll();
    return { success: true };
  }
}
