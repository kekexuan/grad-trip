import { APP_FILTER } from '@nestjs/core';
import { Module } from '@nestjs/common';
import { PlatformModule } from '@lark-apaas/fullstack-nestjs-core';

import { GlobalExceptionFilter } from './common/filters/exception.filter';
import { ViewModule } from './modules/view/view.module';
import { TripsModule } from './modules/trips/trips.module';
import { MembersModule } from './modules/members/members.module';
import { ItineraryModule } from './modules/itinerary/itinerary.module';
import { ExpensesModule } from './modules/expenses/expenses.module';
import { TodosModule } from './modules/todos/todos.module';
import { GroupsModule } from './modules/groups/groups.module';
import { ArchiveModule } from './modules/archive/archive.module';

@Module({
  imports: [
    PlatformModule.forRoot(),
    // ====== @route-section: business-modules START ======
    TripsModule,
    MembersModule,
    ItineraryModule,
    ExpensesModule,
    TodosModule,
    GroupsModule,
    ArchiveModule,
    // ====== @route-section: business-modules END ======

    ViewModule,
  ],
  providers: [
    {
      provide: APP_FILTER,
      useClass: GlobalExceptionFilter,
    },
  ],
})
export class AppModule {}
