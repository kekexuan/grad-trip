# 毕业旅行拼团规划 - AGENTS.md

## 应用概览

面向毕业生群体的旅行拼团规划工具，帮助学生快速组队、统一行程、分摊费用。

## 技术架构

- 前端：React 19 + TypeScript + Tailwind CSS + shadcn/ui
- 后端：NestJS 10 + Drizzle ORM + PostgreSQL
- 图表：ReactECharts
- 数据持久化：全部业务数据存入 PostgreSQL

## 数据模型

### trips 旅程表
- id, name, destination, startDate, endDate, budgetPerPerson

### members 成员表
- id, tripId, name, destinationPreference, budgetTier, notes
- budgetTier: 'economy' | 'standard' | 'premium'

### itinerary_items 行程安排表
- id, tripId, dayIndex, time, content, estimatedCost, category, notes

### expenses 账单支出表
- id, tripId, item, amount, payerId, category, note

### expense_shares 账单分摊关联表
- id, expenseId, memberId, amount

### todos 待办表
- id, tripId, content, completed

### groups 分组表
- id, tripId, groupName

### group_members 分组成员关联表
- id, groupId, memberId

## 设计规范

### 色彩系统
- 主色：#6366f1（Indigo 500）- 青春活力
- 辅助色：#ec4899（Pink 500）- 旅行氛围
- 成功：#10b981（Emerald 500）
- 警告：#f59e0b（Amber 500）
- 错误：#ef4444（Red 500）
- 背景：#f8fafc
- 卡片：#ffffff
- 文字主：#1e293b
- 文字次：#64748b

### 排版
- 标题：text-2xl font-bold
- 副标题：text-lg font-semibold
- 正文：text-base
- 辅助文字：text-sm text-slate-500

### 间距
- 页面内边距：p-6
- 卡片内边距：p-5
- 元素间距：gap-4
- 区块间距：space-y-6

### 布局
- 顶部导航 + 侧边栏 + 主内容区
- 响应式：移动端侧边栏可折叠
- 卡片圆角：rounded-xl
- 阴影：shadow-sm

### 导航
- 首页概览
- 旅程管理
- 组队拼团
- 行程规划
- 账单分摊
- 待办清单
