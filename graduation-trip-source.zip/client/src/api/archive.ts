import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type { ExportArchive, ImportResult } from '@shared/api.interface';

export async function exportArchive(tripId: string): Promise<ExportArchive> {
  try {
    const res = await axiosForBackend.get(`/api/archive/export/${tripId}`);
    return res.data;
  } catch (e) {
    logger.error('导出存档失败', e);
    throw e;
  }
}

export async function importArchive(
  data: ExportArchive,
): Promise<ImportResult> {
  try {
    const res = await axiosForBackend.post('/api/archive/import', data);
    return res.data;
  } catch (e) {
    logger.error('导入存档失败', e);
    throw e;
  }
}

export async function loadSampleData(): Promise<ImportResult> {
  try {
    const res = await axiosForBackend.post('/api/archive/sample');
    return res.data;
  } catch (e) {
    logger.error('加载示例数据失败', e);
    throw e;
  }
}

export async function clearAllData(): Promise<void> {
  try {
    await axiosForBackend.delete('/api/archive/all');
  } catch (e) {
    logger.error('清空数据失败', e);
    throw e;
  }
}
