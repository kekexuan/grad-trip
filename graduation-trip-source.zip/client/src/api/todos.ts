import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  Todo,
  CreateTodoRequest,
  UpdateTodoRequest,
} from '@shared/api.interface';

export async function listTodos(tripId: string): Promise<Todo[]> {
  try {
    const res = await axiosForBackend.get('/api/todos', {
      params: { tripId },
    });
    return res.data;
  } catch (e) {
    logger.error('获取待办列表失败', e);
    throw e;
  }
}

export async function createTodo(data: CreateTodoRequest): Promise<Todo> {
  try {
    const res = await axiosForBackend.post('/api/todos', data);
    return res.data;
  } catch (e) {
    logger.error('创建待办失败', e);
    throw e;
  }
}

export async function updateTodo(
  id: string,
  data: UpdateTodoRequest,
): Promise<Todo> {
  try {
    const res = await axiosForBackend.patch(`/api/todos/${id}`, data);
    return res.data;
  } catch (e) {
    logger.error('更新待办失败', e);
    throw e;
  }
}

export async function deleteTodo(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/todos/${id}`);
  } catch (e) {
    logger.error('删除待办失败', e);
    throw e;
  }
}
