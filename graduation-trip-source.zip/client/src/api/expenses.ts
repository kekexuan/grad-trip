import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  Expense,
  ExpenseSummary,
  CreateExpenseRequest,
  UpdateExpenseRequest,
} from '@shared/api.interface';

export async function listExpenses(tripId: string): Promise<Expense[]> {
  try {
    const res = await axiosForBackend.get('/api/expenses', {
      params: { tripId },
    });
    return res.data;
  } catch (e) {
    logger.error('获取账单列表失败', e);
    throw e;
  }
}

export async function getExpenseSummary(tripId: string): Promise<ExpenseSummary> {
  try {
    const res = await axiosForBackend.get('/api/expenses/summary', {
      params: { tripId },
    });
    return res.data;
  } catch (e) {
    logger.error('获取账单汇总失败', e);
    throw e;
  }
}

export async function createExpense(
  data: CreateExpenseRequest,
): Promise<Expense> {
  try {
    const res = await axiosForBackend.post('/api/expenses', data);
    return res.data;
  } catch (e) {
    logger.error('创建账单失败', e);
    throw e;
  }
}

export async function updateExpense(
  id: string,
  data: UpdateExpenseRequest,
): Promise<Expense> {
  try {
    const res = await axiosForBackend.patch(`/api/expenses/${id}`, data);
    return res.data;
  } catch (e) {
    logger.error('更新账单失败', e);
    throw e;
  }
}

export async function deleteExpense(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/expenses/${id}`);
  } catch (e) {
    logger.error('删除账单失败', e);
    throw e;
  }
}
