import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  ItineraryItem,
  ItinerarySummary,
  CreateItineraryItemRequest,
  UpdateItineraryItemRequest,
} from '@shared/api.interface';

export async function listItineraryItems(
  tripId: string,
): Promise<ItineraryItem[]> {
  try {
    const res = await axiosForBackend.get('/api/itinerary', {
      params: { tripId },
    });
    return res.data;
  } catch (e) {
    logger.error('获取行程列表失败', e);
    throw e;
  }
}

export async function getItinerarySummary(
  tripId: string,
): Promise<ItinerarySummary> {
  try {
    const res = await axiosForBackend.get('/api/itinerary/summary', {
      params: { tripId },
    });
    return res.data;
  } catch (e) {
    logger.error('获取行程汇总失败', e);
    throw e;
  }
}

export async function createItineraryItem(
  data: CreateItineraryItemRequest,
): Promise<ItineraryItem> {
  try {
    const res = await axiosForBackend.post('/api/itinerary', data);
    return res.data;
  } catch (e) {
    logger.error('创建行程项失败', e);
    throw e;
  }
}

export async function updateItineraryItem(
  id: string,
  data: UpdateItineraryItemRequest,
): Promise<ItineraryItem> {
  try {
    const res = await axiosForBackend.patch(`/api/itinerary/${id}`, data);
    return res.data;
  } catch (e) {
    logger.error('更新行程项失败', e);
    throw e;
  }
}

export async function deleteItineraryItem(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/itinerary/${id}`);
  } catch (e) {
    logger.error('删除行程项失败', e);
    throw e;
  }
}
