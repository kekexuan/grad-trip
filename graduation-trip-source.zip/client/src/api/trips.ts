import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  Trip,
  TripDetail,
  CreateTripRequest,
  UpdateTripRequest,
} from '@shared/api.interface';

export async function listTrips(): Promise<Trip[]> {
  try {
    const res = await axiosForBackend.get('/api/trips');
    return res.data;
  } catch (e) {
    logger.error('获取旅程列表失败', e);
    throw e;
  }
}

export async function getTrip(id: string): Promise<TripDetail> {
  try {
    const res = await axiosForBackend.get(`/api/trips/${id}`);
    return res.data;
  } catch (e) {
    logger.error('获取旅程详情失败', e);
    throw e;
  }
}

export async function createTrip(data: CreateTripRequest): Promise<Trip> {
  try {
    const res = await axiosForBackend.post('/api/trips', data);
    return res.data;
  } catch (e) {
    logger.error('创建旅程失败', e);
    throw e;
  }
}

export async function updateTrip(
  id: string,
  data: UpdateTripRequest,
): Promise<Trip> {
  try {
    const res = await axiosForBackend.patch(`/api/trips/${id}`, data);
    return res.data;
  } catch (e) {
    logger.error('更新旅程失败', e);
    throw e;
  }
}

export async function deleteTrip(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/trips/${id}`);
  } catch (e) {
    logger.error('删除旅程失败', e);
    throw e;
  }
}
