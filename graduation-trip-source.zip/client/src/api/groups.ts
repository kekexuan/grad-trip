import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  Group,
  GroupSuggestion,
  CreateGroupsRequest,
  SmartGroupRequest,
} from '@shared/api.interface';

export async function listGroups(tripId: string): Promise<Group[]> {
  try {
    const res = await axiosForBackend.get('/api/groups', {
      params: { tripId },
    });
    return res.data;
  } catch (e) {
    logger.error('获取分组列表失败', e);
    throw e;
  }
}

export async function createGroups(data: CreateGroupsRequest): Promise<Group[]> {
  try {
    const res = await axiosForBackend.post('/api/groups', data);
    return res.data;
  } catch (e) {
    logger.error('创建分组失败', e);
    throw e;
  }
}

export async function deleteGroup(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/groups/${id}`);
  } catch (e) {
    logger.error('删除分组失败', e);
    throw e;
  }
}

export async function smartGroup(
  data: SmartGroupRequest,
): Promise<GroupSuggestion[]> {
  try {
    const res = await axiosForBackend.post('/api/groups/smart', data);
    return res.data;
  } catch (e) {
    logger.error('智能分组失败', e);
    throw e;
  }
}
