import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  Member,
  CreateMemberRequest,
  UpdateMemberRequest,
} from '@shared/api.interface';

export async function listMembers(tripId: string): Promise<Member[]> {
  try {
    const res = await axiosForBackend.get('/api/members', {
      params: { tripId },
    });
    return res.data;
  } catch (e) {
    logger.error('获取成员列表失败', e);
    throw e;
  }
}

export async function getMember(id: string): Promise<Member> {
  try {
    const res = await axiosForBackend.get(`/api/members/${id}`);
    return res.data;
  } catch (e) {
    logger.error('获取成员详情失败', e);
    throw e;
  }
}

export async function createMember(data: CreateMemberRequest): Promise<Member> {
  try {
    const res = await axiosForBackend.post('/api/members', data);
    return res.data;
  } catch (e) {
    logger.error('创建成员失败', e);
    throw e;
  }
}

export async function updateMember(
  id: string,
  data: UpdateMemberRequest,
): Promise<Member> {
  try {
    const res = await axiosForBackend.patch(`/api/members/${id}`, data);
    return res.data;
  } catch (e) {
    logger.error('更新成员失败', e);
    throw e;
  }
}

export async function deleteMember(id: string): Promise<void> {
  try {
    await axiosForBackend.delete(`/api/members/${id}`);
  } catch (e) {
    logger.error('删除成员失败', e);
    throw e;
  }
}
