import { useState, useRef } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  Map,
  Home,
  Compass,
  Users,
  Calendar,
  Receipt,
  CheckSquare,
  Download,
  Upload,
  Menu,
  X,
  Database,
  Trash2,
} from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { TripProvider, useTripContext } from '@client/src/context/TripContext';
import * as archiveApi from '@client/src/api/archive';
import type { ExportArchive } from '@shared/api.interface';
import { showConfirm } from '@lark-apaas/client-toolkit';

interface NavItem {
  path: string;
  label: string;
  icon: React.ReactNode;
  end?: boolean;
}

const navItems: NavItem[] = [
  { path: '/', label: '首页概览', icon: <Home size={20} />, end: true },
  { path: '/trips', label: '旅程管理', icon: <Compass size={20} /> },
  { path: '/team', label: '组队拼团', icon: <Users size={20} /> },
  { path: '/itinerary', label: '行程规划', icon: <Calendar size={20} /> },
  { path: '/expenses', label: '账单分摊', icon: <Receipt size={20} /> },
  { path: '/todos', label: '待办清单', icon: <CheckSquare size={20} /> },
];

const pageTitleMap: Record<string, string> = {
  '/': '首页概览',
  '/trips': '旅程管理',
  '/team': '组队拼团',
  '/itinerary': '行程规划',
  '/expenses': '账单分摊',
  '/todos': '待办清单',
};

const Sidebar = ({ sidebarOpen, onClose }: { sidebarOpen: boolean; onClose: () => void }) => {
  const { currentTripId, refreshTrips, setCurrentTrip } = useTripContext();
  const navigate = useNavigate();

  const handleLoadSample = async () => {
    try {
      const result = await archiveApi.loadSampleData();
      toast.success(`示例数据加载成功！添加了 ${result.membersCount} 位成员、${result.itineraryItemsCount} 条行程、${result.expensesCount} 笔支出`);
      await refreshTrips();
      setCurrentTrip(result.tripId);
      navigate('/');
    } catch (e) {
      logger.error('加载示例数据失败', e);
      toast.error('加载示例数据失败');
    }
  };

  const handleClearData = async () => {
    if (!await showConfirm('确定要清空所有数据吗？此操作不可撤销。')) return;
    try {
      await archiveApi.clearAllData();
      toast.success('已清空所有数据');
      await refreshTrips();
      setCurrentTrip(null);
    } catch (e) {
      logger.error('清空数据失败', e);
      toast.error('清空数据失败');
    }
  };

  return (
    <aside
      className={`
        fixed md:static z-40 h-full w-64 bg-white border-r border-slate-200
        flex flex-col flex-shrink-0
        transform transition-transform duration-200 ease-in-out
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}
    >
      {/* Logo */}
      <div className="h-16 flex items-center gap-3 px-6 border-b border-slate-100">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-pink-500 flex items-center justify-center text-white shadow-sm">
          <Map size={20} />
        </div>
        <div>
          <h1 className="text-base font-bold text-slate-800 leading-tight">
            毕业旅行拼团
          </h1>
          <p className="text-xs text-slate-400">规划助手</p>
        </div>
        <button
          className="ml-auto md:hidden text-slate-400 hover:text-slate-600"
          onClick={onClose}
          aria-label="关闭侧边栏"
        >
          <X size={20} />
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map((item: NavItem) => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.end}
            onClick={onClose}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isActive
                  ? 'text-indigo-600 bg-indigo-50'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`
            }
          >
            {item.icon}
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      {/* Bottom actions */}
      <div className="p-3 border-t border-slate-100 space-y-2">
        <button
          onClick={handleLoadSample}
          className="w-full flex items-center gap-2 px-3 py-2 text-sm text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
          aria-label="加载示例数据"
        >
          <Database size={18} />
          <span>加载示例数据</span>
        </button>
        <button
          onClick={handleClearData}
          className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-500 hover:bg-slate-50 hover:text-red-500 rounded-lg transition-colors"
          aria-label="清空重新开始"
        >
          <Trash2 size={18} />
          <span>清空重新开始</span>
        </button>
      </div>
    </aside>
  );
};

const TopBar = ({ onMenuClick }: { onMenuClick: () => void }) => {
  const location = useLocation();
  const { currentTripId, refreshCurrentTrip, setCurrentTrip, refreshTrips } = useTripContext();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentPageTitle =
    pageTitleMap[location.pathname] ?? '毕业旅行拼团规划';

  const handleExport = async () => {
    if (!currentTripId) {
      toast.warning('请先选择一个旅程');
      return;
    }
    try {
      const data = await archiveApi.exportArchive(currentTripId);
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${data.trip.name}-存档.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('导出成功');
    } catch (e) {
      logger.error('导出失败', e);
      toast.error('导出失败');
    }
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data: ExportArchive = JSON.parse(text);
      const result = await archiveApi.importArchive(data);
      toast.success(`导入成功！新旅程：${data.trip.name}`);
      await refreshTrips();
      setCurrentTrip(result.tripId);
    } catch (err) {
      logger.error('导入失败', err);
      toast.error('导入失败：文件格式不正确');
    }
    e.target.value = '';
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center px-6 gap-4 flex-shrink-0">
      <button
        className="md:hidden text-slate-500 hover:text-slate-700"
        onClick={onMenuClick}
        aria-label="打开菜单"
      >
        <Menu size={20} />
      </button>
      <h2 className="text-lg font-semibold text-slate-800">
        {currentPageTitle}
      </h2>
      <div className="flex-1" />
      <div className="flex items-center gap-2">
        <input
          ref={fileInputRef}
          type="file"
          accept=".json"
          className="hidden"
          onChange={handleImportFile}
        />
        <button
          onClick={handleImportClick}
          className="flex items-center gap-2 px-3 py-2 text-sm text-slate-600 hover:bg-slate-50 rounded-lg border border-slate-200 transition-colors"
          aria-label="导入存档"
        >
          <Upload size={16} />
          <span className="hidden sm:inline">导入</span>
        </button>
        <button
          onClick={handleExport}
          className="flex items-center gap-2 px-3 py-2 text-sm text-white bg-indigo-500 hover:bg-indigo-600 rounded-lg transition-colors"
          aria-label="导出存档"
        >
          <Download size={16} />
          <span className="hidden sm:inline">导出</span>
        </button>
      </div>
    </header>
  );
};

const LayoutInner = () => {
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);

  return (
    <div className="flex h-screen w-screen bg-slate-50 overflow-hidden">
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/30 z-30 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      <Sidebar sidebarOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar onMenuClick={() => setSidebarOpen(true)} />
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

const Layout = () => {
  return (
    <TripProvider>
      <LayoutInner />
    </TripProvider>
  );
};

export default Layout;
