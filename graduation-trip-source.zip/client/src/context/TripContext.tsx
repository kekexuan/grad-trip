import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { listTrips, getTrip } from '@client/src/api/trips';
import type { Trip, TripDetail } from '@shared/api.interface';

interface TripContextValue {
  trips: Trip[];
  currentTripId: string | null;
  currentTrip: TripDetail | null;
  loading: boolean;
  setCurrentTrip: (tripId: string | null) => void;
  refreshTrips: () => Promise<void>;
  refreshCurrentTrip: () => Promise<void>;
}

const TripContext = createContext<TripContextValue | undefined>(undefined);

interface TripProviderProps {
  children: React.ReactNode;
}

export const TripProvider: React.FC<TripProviderProps> = ({ children }) => {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [currentTripId, setCurrentTripIdState] = useState<string | null>(null);
  const [currentTrip, setCurrentTripDetail] = useState<TripDetail | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchTrips = useCallback(async () => {
    try {
      setLoading(true);
      const data: Trip[] = await listTrips();
      setTrips(data);
      if (data.length > 0 && !currentTripId) {
        setCurrentTripIdState(data[0].id);
      }
    } catch (e) {
      logger.error('加载旅程列表失败', e);
    } finally {
      setLoading(false);
    }
  }, [currentTripId]);

  const fetchCurrentTripDetail = useCallback(async () => {
    if (!currentTripId) {
      setCurrentTripDetail(null);
      return;
    }
    try {
      const data: TripDetail = await getTrip(currentTripId);
      setCurrentTripDetail(data);
    } catch (e) {
      logger.error('加载当前旅程详情失败', e);
    }
  }, [currentTripId]);

  useEffect(() => {
    void fetchTrips();
  }, [fetchTrips]);

  useEffect(() => {
    if (currentTripId) {
      void fetchCurrentTripDetail();
    }
  }, [currentTripId, fetchCurrentTripDetail]);

  const setCurrentTrip = useCallback((tripId: string | null) => {
    setCurrentTripIdState(tripId);
  }, []);

  const value = useMemo<TripContextValue>(
    () => ({
      trips,
      currentTripId,
      currentTrip,
      loading,
      setCurrentTrip,
      refreshTrips: fetchTrips,
      refreshCurrentTrip: fetchCurrentTripDetail,
    }),
    [
      trips,
      currentTripId,
      currentTrip,
      loading,
      setCurrentTrip,
      fetchTrips,
      fetchCurrentTripDetail,
    ],
  );

  return <TripContext.Provider value={value}>{children}</TripContext.Provider>;
};

export function useTripContext(): TripContextValue {
  const context = useContext(TripContext);
  if (context === undefined) {
    throw new Error('useTripContext must be used within a TripProvider');
  }
  return context;
}
