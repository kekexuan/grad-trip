import React from 'react';
import { Route, Routes } from 'react-router-dom';

import Layout from './components/Layout';
import NotFound from './pages/NotFound/NotFound';
import DashboardPage from './pages/Dashboard/DashboardPage';
import TripsPage from './pages/Trips/TripsPage';
import TeamPage from './pages/Team/TeamPage';
import ItineraryPage from './pages/Itinerary/ItineraryPage';
import ExpensesPage from './pages/Expenses/ExpensesPage';
import TodosPage from './pages/Todos/TodosPage';

const RoutesComponent = () => {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<DashboardPage />} />
        <Route path="trips" element={<TripsPage />} />
        <Route path="team" element={<TeamPage />} />
        <Route path="itinerary" element={<ItineraryPage />} />
        <Route path="expenses" element={<ExpensesPage />} />
        <Route path="todos" element={<TodosPage />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default RoutesComponent;
