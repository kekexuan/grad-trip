import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import {
  Users,
  Plus,
  Pencil,
  Trash2,
  Sparkles,
  Save,
  RefreshCw,
  MapPin,
  Wallet,
  Shuffle,
} from 'lucide-react';
import { useTripContext } from '@client/src/context/TripContext';
import {
  createMember,
  deleteMember,
  listMembers,
  updateMember,
} from '@client/src/api/members';
import { createGroups, smartGroup } from '@client/src/api/groups';
import type { Member, GroupSuggestion, BudgetTier } from '@shared/api.interface';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@client/src/components/ui/card';
import { Badge } from '@client/src/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@client/src/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@client/src/components/ui/empty';
import { Skeleton } from '@client/src/components/ui/skeleton';

const memberFormSchema = z.object({
  name: z.string().min(1, '请输入姓名'),
  destinationPreference: z.string().min(1, '请输入目的地偏好'),
  budgetTier: z.enum(['economy', 'standard', 'premium']),
  notes: z.string().optional(),
});

type MemberFormValues = z.infer<typeof memberFormSchema>;

const budgetTierLabels: Record<BudgetTier, string> = {
  economy: '经济档',
  standard: '标准档',
  premium: '豪华档',
};

const budgetTierColors: Record<BudgetTier, string> = {
  economy: 'bg-slate-100 text-slate-700 border-slate-200',
  standard: 'bg-blue-50 text-blue-700 border-blue-200',
  premium: 'bg-amber-50 text-amber-700 border-amber-200',
};

const TeamPage: React.FC = () => {
  const { currentTripId, refreshCurrentTrip } = useTripContext();
  const [members, setMembers] = useState<Member[]>([]);
  const [membersLoading, setMembersLoading] = useState<boolean>(false);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [submitLoading, setSubmitLoading] = useState<boolean>(false);

  const [groupCount, setGroupCount] = useState<number>(2);
  const [groupSuggestions, setGroupSuggestions] = useState<GroupSuggestion[]>([]);
  const [groupingLoading, setGroupingLoading] = useState<boolean>(false);
  const [savingGroups, setSavingGroups] = useState<boolean>(false);
  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);
  const [editingGroupName, setEditingGroupName] = useState<string>('');

  const form = useForm<MemberFormValues>({
    resolver: zodResolver(memberFormSchema),
    defaultValues: {
      name: '',
      destinationPreference: '',
      budgetTier: 'standard',
      notes: '',
    },
  });

  useEffect(() => {
    if (currentTripId) {
      void fetchMembers();
    }
  }, [currentTripId]);

  const fetchMembers = async () => {
    if (!currentTripId) return;
    try {
      setMembersLoading(true);
      const data: Member[] = await listMembers(currentTripId);
      setMembers(data);
    } catch (e) {
      logger.error('加载成员列表失败', e);
      toast.error('加载成员列表失败');
    } finally {
      setMembersLoading(false);
    }
  };

  const openAddDialog = () => {
    setEditingMember(null);
    form.reset({
      name: '',
      destinationPreference: '',
      budgetTier: 'standard',
      notes: '',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (member: Member) => {
    setEditingMember(member);
    form.reset({
      name: member.name,
      destinationPreference: member.destinationPreference,
      budgetTier: member.budgetTier,
      notes: member.notes,
    });
    setDialogOpen(true);
  };

  const handleSubmit = async (values: MemberFormValues) => {
    if (!currentTripId) return;
    try {
      setSubmitLoading(true);
      if (editingMember) {
        await updateMember(editingMember.id, values);
        toast.success('成员更新成功');
      } else {
        await createMember({ ...values, tripId: currentTripId, notes: values.notes ?? '' });
        toast.success('成员添加成功');
      }
      setDialogOpen(false);
      void fetchMembers();
      void refreshCurrentTrip();
    } catch (e) {
      logger.error('保存成员失败', e);
      toast.error('保存成员失败');
    } finally {
      setSubmitLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteMember(id);
      toast.success('成员已删除');
      void fetchMembers();
      void refreshCurrentTrip();
    } catch (e) {
      logger.error('删除成员失败', e);
      toast.error('删除成员失败');
    }
  };

  const handleSmartGroup = async () => {
    if (!currentTripId || members.length === 0) return;
    try {
      setGroupingLoading(true);
      const result: GroupSuggestion[] = await smartGroup({
        tripId: currentTripId,
        groupCount,
      });
      setGroupSuggestions(result);
      toast.success('智能分组完成');
    } catch (e) {
      logger.error('智能分组失败', e);
      toast.error('智能分组失败');
    } finally {
      setGroupingLoading(false);
    }
  };

  const handleSaveGroups = async () => {
    if (!currentTripId || groupSuggestions.length === 0) return;
    try {
      setSavingGroups(true);
      await createGroups({
        tripId: currentTripId,
        groups: groupSuggestions.map((g: GroupSuggestion) => ({
          groupName: g.groupName,
          memberIds: g.memberIds,
        })),
      });
      toast.success('分组已保存');
      void refreshCurrentTrip();
    } catch (e) {
      logger.error('保存分组失败', e);
      toast.error('保存分组失败');
    } finally {
      setSavingGroups(false);
    }
  };

  const handleStartEditGroupName = (group: GroupSuggestion) => {
    setEditingGroupId(group.id);
    setEditingGroupName(group.groupName);
  };

  const handleConfirmGroupName = () => {
    if (!editingGroupId || !editingGroupName.trim()) {
      setEditingGroupId(null);
      return;
    }
    setGroupSuggestions((prev: GroupSuggestion[]) =>
      prev.map((g: GroupSuggestion) =>
        g.id === editingGroupId ? { ...g, groupName: editingGroupName.trim() } : g,
      ),
    );
    setEditingGroupId(null);
  };

  const memberMap = new Map(members.map((m: Member) => [m.id, m]));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">组队拼团</h1>
        <p className="text-sm text-slate-500 mt-1">
          添加同行小伙伴，根据预算偏好智能分组，找到最佳旅伴
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 左侧：成员管理 */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-4">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Users className="h-5 w-5 text-indigo-500" />
              成员列表
              <Badge variant="secondary" className="ml-1">
                {members.length} 人
              </Badge>
            </CardTitle>
            <Button size="sm" onClick={openAddDialog}>
              <Plus className="h-4 w-4" />
              添加成员
            </Button>
          </CardHeader>
          <CardContent>
            {membersLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i: number) => (
                  <Skeleton key={i} className="h-24 rounded-xl" />
                ))}
              </div>
            ) : members.length === 0 ? (
              <Empty className="border-slate-200">
                <EmptyHeader>
                  <EmptyMedia variant="icon" className="bg-indigo-50 text-indigo-500">
                    <Users className="h-6 w-6" />
                  </EmptyMedia>
                  <EmptyTitle>暂无成员</EmptyTitle>
                  <EmptyDescription>
                    添加第一位同行的小伙伴，开启毕业旅行吧
                  </EmptyDescription>
                </EmptyHeader>
                <EmptyContent>
                  <Button size="sm" onClick={openAddDialog}>
                    <Plus className="h-4 w-4" />
                    添加成员
                  </Button>
                </EmptyContent>
              </Empty>
            ) : (
              <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
                {members.map((member: Member) => (
                  <div
                    key={member.id}
                    className="rounded-xl border border-slate-200 p-4 bg-white hover:border-indigo-200 hover:shadow-sm transition-all"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <h3 className="text-lg font-semibold text-slate-800 truncate">
                          {member.name}
                        </h3>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Badge
                            variant="outline"
                            className="flex items-center gap-1 text-slate-600"
                          >
                            <MapPin className="h-3 w-3" />
                            {member.destinationPreference}
                          </Badge>
                          <Badge
                            variant="outline"
                            className={`flex items-center gap-1 ${budgetTierColors[member.budgetTier]}`}
                          >
                            <Wallet className="h-3 w-3" />
                            {budgetTierLabels[member.budgetTier]}
                          </Badge>
                        </div>
                        {member.notes && (
                          <p className="text-sm text-slate-500 mt-2 line-clamp-2">
                            {member.notes}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-1 ml-3">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 text-slate-400 hover:text-indigo-500 hover:bg-indigo-50"
                          onClick={() => openEditDialog(member)}
                          aria-label={`编辑 ${member.name}`}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 text-slate-400 hover:text-red-500 hover:bg-red-50"
                          onClick={() => handleDelete(member.id)}
                          aria-label={`删除 ${member.name}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* 右侧：智能拼团 */}
        <Card>
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-pink-500" />
                智能拼团
              </CardTitle>
              {groupSuggestions.length > 0 && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleSaveGroups}
                  disabled={savingGroups}
                >
                  <Save className="h-4 w-4" />
                  {savingGroups ? '保存中...' : '保存分组'}
                </Button>
              )}
            </div>
            <div className="flex items-center gap-3 mt-3">
              <div className="flex items-center gap-2 flex-1">
                <span className="text-sm text-slate-500 whitespace-nowrap">分组数量：</span>
                <Select
                  value={String(groupCount)}
                  onValueChange={(val: string) => setGroupCount(Number(val))}
                >
                  <SelectTrigger className="w-24">
                    <SelectValue placeholder="组数" />
                  </SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4].map((n: number) => (
                      <SelectItem key={n} value={String(n)}>
                        {n} 组
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button
                size="sm"
                onClick={handleSmartGroup}
                disabled={members.length === 0 || groupingLoading}
              >
                {groupSuggestions.length > 0 ? (
                  <RefreshCw className={`h-4 w-4 ${groupingLoading ? 'animate-spin' : ''}`} />
                ) : (
                  <Shuffle className="h-4 w-4" />
                )}
                {groupingLoading ? '分组中...' : groupSuggestions.length > 0 ? '重新生成' : '智能分组'}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {members.length === 0 ? (
              <Empty className="border-slate-200">
                <EmptyHeader>
                  <EmptyMedia variant="icon" className="bg-pink-50 text-pink-500">
                    <Users className="h-6 w-6" />
                  </EmptyMedia>
                  <EmptyTitle>请先添加成员</EmptyTitle>
                  <EmptyDescription>
                    在左侧添加成员后，才能进行智能分组
                  </EmptyDescription>
                </EmptyHeader>
              </Empty>
            ) : groupSuggestions.length === 0 ? (
              <Empty className="border-slate-200">
                <EmptyHeader>
                  <EmptyMedia variant="icon" className="bg-pink-50 text-pink-500">
                    <Shuffle className="h-6 w-6" />
                  </EmptyMedia>
                  <EmptyTitle>尚未分组</EmptyTitle>
                  <EmptyDescription>
                    选择分组数量，点击「智能分组」一键生成最优组队方案
                  </EmptyDescription>
                </EmptyHeader>
                <EmptyContent>
                  <Button size="sm" onClick={handleSmartGroup} disabled={groupingLoading}>
                    <Sparkles className="h-4 w-4" />
                    开始智能分组
                  </Button>
                </EmptyContent>
              </Empty>
            ) : (
              <div className="space-y-4 max-h-[600px] overflow-y-auto pr-1">
                {groupSuggestions.map((group: GroupSuggestion) => (
                  <div
                    key={group.id}
                    className="rounded-xl border border-slate-200 p-4 bg-slate-50/50"
                  >
                    <div className="flex items-center justify-between mb-3">
                      {editingGroupId === group.id ? (
                        <div className="flex items-center gap-2 flex-1">
                          <Input
                            value={editingGroupName}
                            onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                              setEditingGroupName(e.target.value)
                            }
                            onBlur={handleConfirmGroupName}
                            onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                              if (e.key === 'Enter') handleConfirmGroupName();
                              if (e.key === 'Escape') setEditingGroupId(null);
                            }}
                            className="h-8 text-base font-semibold"
                            autoFocus
                          />
                        </div>
                      ) : (
                        <div
                          className="flex items-center gap-2 cursor-pointer group"
                          onClick={() => handleStartEditGroupName(group)}
                        >
                          <h3 className="text-base font-semibold text-slate-800">
                            {group.groupName}
                          </h3>
                          <Pencil className="h-3.5 w-3.5 text-slate-300 group-hover:text-indigo-400 opacity-0 group-hover:opacity-100 transition-all" />
                        </div>
                      )}
                      <div className="flex items-center gap-2 text-sm">
                        <Badge variant="secondary">{group.memberIds.length} 人</Badge>
                        <Badge variant="outline" className="text-emerald-600 bg-emerald-50 border-emerald-200">
                          人均 ¥{group.avgBudget.toFixed(0)}
                        </Badge>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {group.memberIds.map((memberId: string, idx: number) => {
                        const m: Member | undefined = memberMap.get(memberId);
                        if (!m) return null;
                        return (
                          <div
                            key={memberId}
                            className="flex items-center gap-3 bg-white rounded-lg px-3 py-2 border border-slate-100"
                          >
                            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-indigo-400 to-pink-400 flex items-center justify-center text-white text-xs font-medium">
                              {m.name.charAt(0)}
                            </div>
                            <span className="text-sm font-medium text-slate-700 flex-1">
                              {m.name}
                            </span>
                            <span className="text-xs text-slate-400">
                              {idx === 0 ? '组长' : ''}
                            </span>
                            <Badge
                              variant="outline"
                              className={`text-xs ${budgetTierColors[m.budgetTier]}`}
                            >
                              {budgetTierLabels[m.budgetTier]}
                            </Badge>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* 成员表单弹窗 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingMember ? '编辑成员' : '添加成员'}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>姓名</FormLabel>
                    <FormControl>
                      <Input placeholder="请输入姓名" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="destinationPreference"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>目的地偏好</FormLabel>
                    <FormControl>
                      <Input placeholder="如：海边、古镇、雪山" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="budgetTier"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>预算档位</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="选择预算档位" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="economy">经济档</SelectItem>
                        <SelectItem value="standard">标准档</SelectItem>
                        <SelectItem value="premium">豪华档</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>备注（选填）</FormLabel>
                    <FormControl>
                      <Textarea placeholder="其他需要说明的信息" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                >
                  取消
                </Button>
                <Button type="submit" disabled={submitLoading}>
                  {submitLoading ? '保存中...' : editingMember ? '保存修改' : '添加成员'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TeamPage;
