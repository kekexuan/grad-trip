import { useCallback, useEffect, useMemo, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import {
  Plus,
  Pencil,
  Trash2,
  MapPin,
  CalendarDays,
  ListTodo,
  CalendarPlus,
} from 'lucide-react';

import { useTripContext } from '@client/src/context/TripContext';
import {
  createItineraryItem,
  deleteItineraryItem,
  getItinerarySummary,
  listItineraryItems,
  updateItineraryItem,
} from '@client/src/api/itinerary';
import type {
  ItineraryItem,
  ItinerarySummary,
} from '@shared/api.interface';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@/components/ui/empty';
import { Skeleton } from '@/components/ui/skeleton';
import {
  CATEGORY_COLORS,
  CATEGORY_LABELS,
  ITINERARY_CATEGORIES,
} from '@/utils/category-config';

const formSchema = z.object({
  dayIndex: z.coerce.number().int().min(1, '天数必须大于等于 1'),
  timeSlot: z.string().min(1, '请输入时间'),
  content: z.string().min(1, '请输入行程内容'),
  estimatedCost: z.coerce.number().min(0, '预估费用不能为负数'),
  category: z.enum([
    'transportation',
    'accommodation',
    'food',
    'attraction',
    'shopping',
    'other',
  ]),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const ItineraryPage = () => {
  const { currentTripId, currentTrip, loading: tripLoading } = useTripContext();
  const [items, setItems] = useState<ItineraryItem[]>([]);
  const [summary, setSummary] = useState<ItinerarySummary | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [editingItem, setEditingItem] = useState<ItineraryItem | null>(null);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [activeDay, setActiveDay] = useState<string>('1');

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema) as unknown as Parameters<
      typeof useForm<FormValues>
    >[0]['resolver'],
    defaultValues: {
      dayIndex: 1,
      timeSlot: '',
      content: '',
      estimatedCost: 0,
      category: 'other',
      notes: '',
    },
  });

  const fetchData = useCallback(async () => {
    if (!currentTripId) {
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      const [itemsData, summaryData] = await Promise.all([
        listItineraryItems(currentTripId),
        getItinerarySummary(currentTripId),
      ]);
      setItems(itemsData);
      setSummary(summaryData);
      if (summaryData.dayCount > 0) {
        setActiveDay('1');
      }
    } catch (e) {
      logger.error('加载行程数据失败', e);
      toast.error('加载行程数据失败');
    } finally {
      setLoading(false);
    }
  }, [currentTripId]);

  useEffect(() => {
    void fetchData();
  }, [fetchData]);

  const totalDays = useMemo(() => {
    if (!currentTrip?.startDate || !currentTrip?.endDate) return summary?.dayCount ?? 0;
    const start = new Date(currentTrip.startDate);
    const end = new Date(currentTrip.endDate);
    const diff = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
    return Math.max(diff, summary?.dayCount ?? 0);
  }, [currentTrip, summary]);

  const itemsByDay = useMemo(() => {
    const map = new Map<number, ItineraryItem[]>();
    for (const item of items) {
      const list = map.get(item.dayIndex) ?? [];
      list.push(item);
      map.set(item.dayIndex, list);
    }
    for (const [, list] of map) {
      list.sort((a, b) => a.timeSlot.localeCompare(b.timeSlot));
    }
    return map;
  }, [items]);

  const dayList = useMemo(() => {
    const maxDay = Math.max(totalDays, summary?.dayCount ?? 0, 1);
    return Array.from({ length: maxDay }, (_, i) => i + 1);
  }, [totalDays, summary]);

  const handleOpenCreate = () => {
    setEditingItem(null);
    form.reset({
      dayIndex: Number(activeDay) || 1,
      timeSlot: '',
      content: '',
      estimatedCost: 0,
      category: 'other',
      notes: '',
    });
    setDialogOpen(true);
  };

  const handleOpenEdit = (item: ItineraryItem) => {
    setEditingItem(item);
    form.reset({
      dayIndex: item.dayIndex,
      timeSlot: item.timeSlot,
      content: item.content,
      estimatedCost: item.estimatedCost,
      category: item.category,
      notes: item.notes,
    });
    setDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!currentTripId) return;
    try {
      await deleteItineraryItem(id);
      toast.success('删除成功');
      void fetchData();
    } catch (e) {
      logger.error('删除行程失败', e);
      toast.error('删除失败');
    }
  };

  const onSubmit = async (values: FormValues) => {
    if (!currentTripId) return;
    try {
      setSubmitting(true);
      if (editingItem) {
        await updateItineraryItem(editingItem.id, {
          dayIndex: values.dayIndex,
          timeSlot: values.timeSlot,
          content: values.content,
          estimatedCost: values.estimatedCost,
          category: values.category,
          notes: values.notes ?? '',
        });
        toast.success('更新成功');
      } else {
        await createItineraryItem({
          tripId: currentTripId,
          dayIndex: values.dayIndex,
          timeSlot: values.timeSlot,
          content: values.content,
          estimatedCost: values.estimatedCost,
          category: values.category,
          notes: values.notes ?? '',
        });
        toast.success('添加成功');
      }
      setDialogOpen(false);
      void fetchData();
    } catch (e) {
      logger.error('保存行程失败', e);
      toast.error('保存失败');
    } finally {
      setSubmitting(false);
    }
  };

  const pieOption = useMemo<EChartsOption>(() => {
    const data = (summary?.costByCategory ?? []).map((c) => ({
      name: c.categoryLabel,
      value: c.amount,
    }));
    const colors = (summary?.costByCategory ?? []).map(
      (c) =>
        CATEGORY_COLORS[c.category as keyof typeof CATEGORY_COLORS] ?? '#64748b',
    );
    return {
      tooltip: {
        trigger: 'item',
        formatter: (params) => {
          if (Array.isArray(params)) return '';
          return `${params.name}<br/>金额：¥${Number(params.value).toFixed(2)}`;
        },
      },
      legend: {
        type: 'scroll',
        bottom: 0,
      },
      color: colors.length > 0 ? colors : ['#6366f1'],
      series: [
        {
          type: 'pie',
          radius: ['45%', '70%'],
          center: ['50%', '45%'],
          avoidLabelOverlap: false,
          label: { show: false },
          emphasis: { label: { show: false } },
          data,
        },
      ],
    };
  }, [summary]);

  if (tripLoading && !currentTrip) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!currentTripId || !currentTrip) {
    return (
      <div className="p-6">
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <MapPin className="size-6" />
            </EmptyMedia>
            <EmptyTitle>暂无旅程</EmptyTitle>
            <EmptyDescription>请先创建或选择一个旅程</EmptyDescription>
          </EmptyHeader>
        </Empty>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6" data-ai-section-type="card-list">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">行程规划</h1>
          <p className="mt-1 text-sm text-slate-500">
            按天规划旅行行程，安排交通、住宿、景点和美食
          </p>
        </div>
        <Button onClick={handleOpenCreate}>
          <Plus className="size-4" />
          添加行程
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
        {/* 左侧：行程时间轴 */}
        <Card className="overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between pb-4">
            <CardTitle className="text-lg font-semibold">
              <span className="flex items-center gap-2">
                <CalendarDays className="size-5 text-primary" />
                行程时间轴
              </span>
            </CardTitle>
            <Badge variant="secondary">共 {Math.max(totalDays, 1)} 天</Badge>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            ) : dayList.length === 0 ? (
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <CalendarPlus className="size-6" />
                  </EmptyMedia>
                  <EmptyTitle>暂无行程</EmptyTitle>
                  <EmptyDescription>点击右上角添加第一条行程吧</EmptyDescription>
                </EmptyHeader>
              </Empty>
            ) : (
              <Tabs value={activeDay} onValueChange={setActiveDay}>
                <div className="overflow-x-auto pb-2">
                  <TabsList className="inline-flex h-auto flex-wrap gap-1 bg-slate-100 p-1">
                    {dayList.map((day) => (
                      <TabsTrigger
                        key={day}
                        value={String(day)}
                        className="px-3 py-1.5 text-xs"
                      >
                        第 {day} 天
                        {itemsByDay.get(day) && (
                          <span className="ml-1 text-[10px] text-slate-400">
                            ({itemsByDay.get(day)?.length ?? 0})
                          </span>
                        )}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </div>
                {dayList.map((day) => {
                  const dayItems = itemsByDay.get(day) ?? [];
                  return (
                    <TabsContent key={day} value={String(day)} className="mt-4">
                      {dayItems.length === 0 ? (
                        <Empty className="py-8">
                          <EmptyHeader>
                            <EmptyMedia variant="icon">
                              <ListTodo className="size-5" />
                            </EmptyMedia>
                            <EmptyTitle>第 {day} 天暂无安排</EmptyTitle>
                            <EmptyDescription>
                              添加一个行程开始规划吧
                            </EmptyDescription>
                          </EmptyHeader>
                        </Empty>
                      ) : (
                        <div className="relative pl-8">
                          {/* 时间轴竖线 */}
                          <div className="absolute left-2 top-1 bottom-1 w-0.5 bg-slate-200" />
                          <div className="space-y-4">
                            {dayItems.map((item) => (
                              <div key={item.id} className="relative">
                                {/* 圆点 */}
                                <div
                                  className="absolute -left-6 top-4 size-3 rounded-full border-2 border-white"
                                  style={{
                                    backgroundColor:
                                      CATEGORY_COLORS[item.category] ??
                                      '#64748b',
                                  }}
                                />
                                <Card className="transition-shadow hover:shadow-md">
                                  <CardContent className="p-4">
                                    <div className="flex items-start justify-between gap-3">
                                      <div className="min-w-0 flex-1">
                                        <div className="flex items-center gap-2">
                                          <span className="text-sm font-medium text-slate-500">
                                            {item.timeSlot}
                                          </span>
                                          <Badge
                                            variant={
                                              item.category ===
                                                'transportation' ||
                                              item.category === 'attraction'
                                                ? 'default'
                                                : 'secondary'
                                            }
                                            className="text-xs"
                                          >
                                            {CATEGORY_LABELS[item.category]}
                                          </Badge>
                                        </div>
                                        <p className="mt-1 text-base font-medium text-slate-800">
                                          {item.content}
                                        </p>
                                        {item.notes && (
                                          <p className="mt-1 text-sm text-slate-500">
                                            {item.notes}
                                          </p>
                                        )}
                                        <p className="mt-2 text-sm font-semibold text-primary">
                                          ¥{item.estimatedCost.toFixed(2)}
                                          <span className="ml-1 text-xs font-normal text-slate-400">
                                            预估
                                          </span>
                                        </p>
                                      </div>
                                      <div className="flex shrink-0 gap-1">
                                        <Button
                                          size="icon"
                                          variant="ghost"
                                          className="size-8"
                                          aria-label="编辑行程"
                                          onClick={() => handleOpenEdit(item)}
                                        >
                                          <Pencil className="size-4" />
                                        </Button>
                                        <Button
                                          size="icon"
                                          variant="ghost"
                                          className="size-8 text-red-500 hover:text-red-600"
                                          aria-label="删除行程"
                                          onClick={() => handleDelete(item.id)}
                                        >
                                          <Trash2 className="size-4" />
                                        </Button>
                                      </div>
                                    </div>
                                  </CardContent>
                                </Card>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </TabsContent>
                  );
                })}
              </Tabs>
            )}
          </CardContent>
        </Card>

        {/* 右侧：统计面板 */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold">费用统计</CardTitle>
            </CardHeader>
            <CardContent>
              {loading || !summary ? (
                <div className="space-y-4">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-[240px] w-full" />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="rounded-lg bg-gradient-to-r from-indigo-500 to-pink-500 p-4 text-white">
                    <p className="text-xs opacity-90">总预估费用</p>
                    <p className="mt-1 text-3xl font-bold">
                      ¥{summary.totalCost.toFixed(2)}
                    </p>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="rounded-lg bg-slate-50 p-3">
                      <p className="text-xs text-slate-500">行程天数</p>
                      <p className="mt-1 text-xl font-bold text-slate-800">
                        {summary.dayCount} 天
                      </p>
                    </div>
                    <div className="rounded-lg bg-slate-50 p-3">
                      <p className="text-xs text-slate-500">行程项目</p>
                      <p className="mt-1 text-xl font-bold text-slate-800">
                        {summary.itemCount} 项
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold">费用构成</CardTitle>
            </CardHeader>
            <CardContent>
              {loading || !summary ? (
                <Skeleton className="h-[300px] w-full" />
              ) : summary.costByCategory.length === 0 ? (
                <Empty className="py-8">
                  <EmptyHeader>
                    <EmptyTitle className="text-sm">暂无费用数据</EmptyTitle>
                  </EmptyHeader>
                </Empty>
              ) : (
                <ReactECharts
                  option={pieOption}
                  theme="ud"
                  className="h-[300px] w-full"
                />
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 添加/编辑弹窗 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? '编辑行程' : '添加行程'}
            </DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit as SubmitHandler<FormValues>)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="dayIndex"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>天数</FormLabel>
                      <FormControl>
                        <Input type="number" min={1} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="timeSlot"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>时间</FormLabel>
                      <FormControl>
                        <Input placeholder="如 08:00 / 上午" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>行程内容</FormLabel>
                    <FormControl>
                      <Textarea rows={3} placeholder="描述这一行程" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="estimatedCost"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>预估费用 (¥)</FormLabel>
                      <FormControl>
                        <Input type="number" min={0} step="0.01" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>类别</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="选择类别" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {ITINERARY_CATEGORIES.map((cat) => (
                            <SelectItem key={cat} value={cat}>
                              {CATEGORY_LABELS[cat]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>备注</FormLabel>
                    <FormControl>
                      <Textarea rows={2} placeholder="可选" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                >
                  取消
                </Button>
                <Button type="submit" disabled={submitting}>
                  {submitting ? '保存中...' : editingItem ? '保存修改' : '添加'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ItineraryPage;
