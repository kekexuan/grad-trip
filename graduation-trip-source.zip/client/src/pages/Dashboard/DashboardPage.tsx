import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  CalendarDays,
  Wallet,
  CheckSquare,
  ArrowRight,
  Plus,
  Receipt,
  MapPin,
  Sparkles,
  UsersRound,
  Route,
  ClipboardList,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { useTripContext } from '@client/src/context/TripContext';
import { updateTodo } from '@client/src/api/todos';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Checkbox } from '@client/src/components/ui/checkbox';
import { Skeleton } from '@client/src/components/ui/skeleton';
import { Badge } from '@client/src/components/ui/badge';
import type { Expense, ExpenseCategory, Member, Todo } from '@shared/api.interface';

const expenseCategoryLabels: Record<ExpenseCategory, string> = {
  transportation: '交通',
  accommodation: '住宿',
  food: '餐饮',
  attraction: '景点',
  shopping: '购物',
  other: '其他',
};

const expenseCategoryColors: Record<ExpenseCategory, string> = {
  transportation: 'bg-blue-100 text-blue-700',
  accommodation: 'bg-purple-100 text-purple-700',
  food: 'bg-orange-100 text-orange-700',
  attraction: 'bg-emerald-100 text-emerald-700',
  shopping: 'bg-pink-100 text-pink-700',
  other: 'bg-slate-100 text-slate-700',
};

const DashboardPage = () => {
  const navigate = useNavigate();
  const { currentTrip, currentTripId, loading, refreshCurrentTrip } =
    useTripContext();

  const stats = useMemo(() => {
    if (!currentTrip) return null;
    const members: number = currentTrip.members.length;
    const dayCount: number = currentTrip.itineraryItems.reduce(
      (max: number, item) => Math.max(max, item.dayIndex + 1),
      0,
    );
    const totalBudget: number = currentTrip.itineraryItems.reduce(
      (sum: number, item) => sum + (item.estimatedCost || 0),
      0,
    );
    const totalTodos: number = currentTrip.todos.length;
    const completedTodos: number = currentTrip.todos.filter(
      (t: Todo) => t.completed,
    ).length;
    return { members, dayCount, totalBudget, totalTodos, completedTodos };
  }, [currentTrip]);

  const recentExpenses = useMemo<Expense[]>(() => {
    if (!currentTrip) return [];
    return [...currentTrip.expenses].slice(0, 5);
  }, [currentTrip]);

  const pendingTodos = useMemo<Todo[]>(() => {
    if (!currentTrip) return [];
    return currentTrip.todos
      .filter((t: Todo) => !t.completed)
      .slice(0, 5);
  }, [currentTrip]);

  const memberNameMap = useMemo<Map<string, string>>(() => {
    const map = new Map<string, string>();
    if (!currentTrip) return map;
    currentTrip.members.forEach((m: Member) => {
      map.set(m.id, m.name);
    });
    return map;
  }, [currentTrip]);

  const handleToggleTodo = async (todo: Todo) => {
    try {
      await updateTodo(todo.id, { completed: !todo.completed });
      toast.success(todo.completed ? '已取消完成' : '已标记为完成');
      await refreshCurrentTrip();
    } catch (e) {
      logger.error('更新待办失败', e);
      toast.error('更新待办失败，请重试');
    }
  };

  // Loading
  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-4 w-64 mt-2" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i: number) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Skeleton className="h-72 rounded-xl" />
          <Skeleton className="h-72 rounded-xl" />
        </div>
      </div>
    );
  }

  // Empty state - no trip
  if (!currentTrip || !currentTripId) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">首页概览</h1>
          <p className="text-sm text-slate-500 mt-1">
            查看当前旅程的整体进度、花费概览和待办事项
          </p>
        </div>
        <Card className="border-dashed border-2 border-slate-200">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-100 to-pink-100 flex items-center justify-center mb-4">
              <Sparkles className="w-8 h-8 text-indigo-500" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">
              开始你的毕业旅行吧
            </h3>
            <p className="text-sm text-slate-500 mb-6 text-center max-w-sm">
              创建第一个旅程，和小伙伴一起规划行程、分摊费用、记录美好回忆
            </p>
            <Button onClick={() => navigate('/trips')}>
              <Plus size={18} />
              创建第一个旅程
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const progress =
    stats && stats.totalTodos > 0
      ? Math.round((stats.completedTodos / stats.totalTodos) * 100)
      : 0;

  const formatDate = (dateStr: string): string => {
    const d = new Date(dateStr);
    return `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, '0')}.${String(d.getDate()).padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Welcome banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-500 via-indigo-500 to-pink-500 p-6 text-white shadow-sm">
        <div className="relative z-10">
          <div className="flex items-center gap-2 text-indigo-100 text-sm mb-2">
            <MapPin size={16} />
            <span>{currentTrip.destination}</span>
          </div>
          <h1 className="text-2xl font-bold mb-2">{currentTrip.name}</h1>
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-indigo-50">
            <div className="flex items-center gap-2">
              <CalendarDays size={16} />
              <span>
                {formatDate(currentTrip.startDate)} -{' '}
                {formatDate(currentTrip.endDate)}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Wallet size={16} />
              <span>人均预算 ¥{currentTrip.budgetPerPerson.toLocaleString()}</span>
            </div>
          </div>
        </div>
        <div className="absolute -right-10 -bottom-10 w-48 h-48 rounded-full bg-white/10 blur-2xl" />
        <div className="absolute right-20 top-0 w-32 h-32 rounded-full bg-pink-400/30 blur-xl" />
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4" data-ai-section-type="card-stat">
        <div className="rounded-xl p-5 bg-gradient-to-br from-indigo-500 to-indigo-600 text-white shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-indigo-100">成员总数</span>
            <div className="w-9 h-9 rounded-lg bg-white/20 flex items-center justify-center">
              <UsersRound size={18} />
            </div>
          </div>
          <div className="text-3xl font-bold">{stats?.members ?? 0}</div>
          <div className="text-xs text-indigo-200 mt-1">位小伙伴</div>
        </div>

        <div className="rounded-xl p-5 bg-gradient-to-br from-pink-500 to-pink-600 text-white shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-pink-100">行程天数</span>
            <div className="w-9 h-9 rounded-lg bg-white/20 flex items-center justify-center">
              <Route size={18} />
            </div>
          </div>
          <div className="text-3xl font-bold">{stats?.dayCount ?? 0}</div>
          <div className="text-xs text-pink-200 mt-1">天行程安排</div>
        </div>

        <div className="rounded-xl p-5 bg-gradient-to-br from-emerald-500 to-emerald-600 text-white shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-emerald-100">总预算</span>
            <div className="w-9 h-9 rounded-lg bg-white/20 flex items-center justify-center">
              <Wallet size={18} />
            </div>
          </div>
          <div className="text-3xl font-bold">
            ¥{(stats?.totalBudget ?? 0).toLocaleString()}
          </div>
          <div className="text-xs text-emerald-200 mt-1">预估总费用</div>
        </div>

        <div className="rounded-xl p-5 bg-gradient-to-br from-amber-500 to-amber-600 text-white shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-amber-100">待办进度</span>
            <div className="w-9 h-9 rounded-lg bg-white/20 flex items-center justify-center">
              <ClipboardList size={18} />
            </div>
          </div>
          <div className="text-3xl font-bold">
            {stats?.completedTodos ?? 0}/{stats?.totalTodos ?? 0}
          </div>
          <div className="mt-2 w-full bg-white/20 rounded-full h-1.5">
            <div
              className="bg-white rounded-full h-1.5 transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">快速操作</CardTitle>
        </CardHeader>
        <CardContent>
          <div
            className="grid grid-cols-2 md:grid-cols-4 gap-3"
            data-ai-section-type="card-menu"
          >
            {[
              {
                label: '组队拼团',
                icon: <Users size={20} />,
                path: '/team',
                color: 'from-pink-500 to-rose-500',
              },
              {
                label: '行程规划',
                icon: <CalendarDays size={20} />,
                path: '/itinerary',
                color: 'from-indigo-500 to-violet-500',
              },
              {
                label: '账单分摊',
                icon: <Receipt size={20} />,
                path: '/expenses',
                color: 'from-emerald-500 to-teal-500',
              },
              {
                label: '待办清单',
                icon: <CheckSquare size={20} />,
                path: '/todos',
                color: 'from-amber-500 to-orange-500',
              },
            ].map((action) => (
              <button
                key={action.path}
                onClick={() => navigate(action.path)}
                className="group flex items-center gap-3 p-4 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-colors text-left"
              >
                <div
                  className={`w-10 h-10 rounded-lg bg-gradient-to-br ${action.color} text-white flex items-center justify-center flex-shrink-0`}
                >
                  {action.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-slate-800">
                    {action.label}
                  </div>
                  <div className="text-xs text-slate-400 group-hover:text-slate-500 flex items-center gap-1">
                    去查看 <ArrowRight size={12} />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent expenses + pending todos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-base">最近支出</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/expenses')}
              className="text-xs"
            >
              查看全部 <ArrowRight size={14} />
            </Button>
          </CardHeader>
          <CardContent>
            {recentExpenses.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-400">
                暂无支出记录
              </div>
            ) : (
              <div className="space-y-3">
                {recentExpenses.map((expense: Expense) => (
                  <div
                    key={expense.id}
                    className="flex items-center gap-3 py-2"
                  >
                    <Badge
                      variant="secondary"
                      className={expenseCategoryColors[expense.category]}
                    >
                      {expenseCategoryLabels[expense.category]}
                    </Badge>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-slate-800 truncate">
                        {expense.item}
                      </div>
                      <div className="text-xs text-slate-400">
                        付款人：{memberNameMap.get(expense.payerId) ?? '未知'}
                      </div>
                    </div>
                    <div className="text-sm font-semibold text-slate-800">
                      ¥{expense.amount.toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-base">待办预览</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/todos')}
              className="text-xs"
            >
              查看全部 <ArrowRight size={14} />
            </Button>
          </CardHeader>
          <CardContent>
            {pendingTodos.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-400">
                太棒了，没有待办事项 🎉
              </div>
            ) : (
              <div className="space-y-2">
                {pendingTodos.map((todo: Todo) => (
                  <div
                    key={todo.id}
                    className="flex items-center gap-3 py-2 px-2 rounded-lg hover:bg-slate-50"
                  >
                    <Checkbox
                      id={`todo-${todo.id}`}
                      checked={todo.completed}
                      onCheckedChange={() => handleToggleTodo(todo)}
                    />
                    <label
                      htmlFor={`todo-${todo.id}`}
                      className="text-sm text-slate-700 cursor-pointer flex-1"
                    >
                      {todo.content}
                    </label>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DashboardPage;
