import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Plus,
  Pencil,
  Trash2,
  MapPin,
  CalendarDays,
  Wallet,
  Users,
  Compass,
  CheckCircle2,
} from 'lucide-react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import dayjs from 'dayjs';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { useTripContext } from '@client/src/context/TripContext';
import { createTrip, updateTrip, deleteTrip } from '@client/src/api/trips';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@client/src/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@client/src/components/ui/alert-dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import { Input } from '@client/src/components/ui/input';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import { Calendar } from '@client/src/components/ui/calendar';
import { Skeleton } from '@client/src/components/ui/skeleton';
import { Badge } from '@client/src/components/ui/badge';
import type { Trip } from '@shared/api.interface';

const tripSchema = z
  .object({
    name: z.string().min(1, '旅程名称不能为空'),
    destination: z.string().min(1, '目的地不能为空'),
    startDate: z.date(),
    endDate: z.date(),
    budgetPerPerson: z.number().min(0, '预算不能为负数'),
  })
  .refine((data) => data.endDate >= data.startDate, {
    message: '返程日期不能早于出发日期',
    path: ['endDate'],
  });

type TripFormData = z.infer<typeof tripSchema>;

interface TripDialogProps {
  trip?: Trip;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: TripFormData) => Promise<void>;
  mode: 'create' | 'edit';
}

const TripDialog = ({ trip, open, onOpenChange, onSubmit, mode }: TripDialogProps) => {
  const form = useForm<TripFormData>({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resolver: zodResolver(tripSchema) as any,
    defaultValues: trip
      ? {
          name: trip.name,
          destination: trip.destination,
          startDate: new Date(trip.startDate),
          endDate: new Date(trip.endDate),
          budgetPerPerson: trip.budgetPerPerson,
        }
      : {
          name: '',
          destination: '',
          startDate: new Date(),
          endDate: dayjs().add(3, 'day').toDate(),
          budgetPerPerson: 2000,
        },
  });

  const handleSubmit = form.handleSubmit(async (data: TripFormData) => {
    await onSubmit(data);
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{mode === 'create' ? '新建旅程' : '编辑旅程'}</DialogTitle>
          <DialogDescription>
            {mode === 'create'
              ? '创建一个新的毕业旅行计划'
              : '修改旅程的基本信息'}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    旅程名称{' '}
                    <span aria-hidden="true" className="text-destructive">
                      *
                    </span>
                  </FormLabel>
                  <FormControl>
                    <Input placeholder="例如：毕业旅行 · 厦门站" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="destination"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    目的地{' '}
                    <span aria-hidden="true" className="text-destructive">
                      *
                    </span>
                  </FormLabel>
                  <FormControl>
                    <Input placeholder="例如：厦门" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex flex-wrap gap-4">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>
                      出发日期{' '}
                      <span aria-hidden="true" className="text-destructive">
                        *
                      </span>
                    </FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className="w-full justify-start font-normal text-left"
                          >
                            <CalendarDays size={16} className="mr-2 opacity-50" />
                            {field.value
                              ? dayjs(field.value).format('YYYY-MM-DD')
                              : '请选择日期'}
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>
                      返程日期{' '}
                      <span aria-hidden="true" className="text-destructive">
                        *
                      </span>
                    </FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className="w-full justify-start font-normal text-left"
                          >
                            <CalendarDays size={16} className="mr-2 opacity-50" />
                            {field.value
                              ? dayjs(field.value).format('YYYY-MM-DD')
                              : '请选择日期'}
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="budgetPerPerson"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    人均预算（元）{' '}
                    <span aria-hidden="true" className="text-destructive">
                      *
                    </span>
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      placeholder="例如：2000"
                      {...field}
                      onChange={(e) => field.onChange(e.target.valueAsNumber)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                取消
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {mode === 'create' ? '创建旅程' : '保存修改'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

const TripsPage = () => {
  const navigate = useNavigate();
  const { trips, currentTripId, loading, setCurrentTrip, refreshTrips } =
    useTripContext();

  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [editingTrip, setEditingTrip] = useState<Trip | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState<boolean>(false);
  const [deletingTrip, setDeletingTrip] = useState<Trip | null>(null);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [deleting, setDeleting] = useState<boolean>(false);

  const openCreateDialog = () => {
    setEditingTrip(null);
    setDialogOpen(true);
  };

  const openEditDialog = (trip: Trip) => {
    setEditingTrip(trip);
    setDialogOpen(true);
  };

  const openDeleteDialog = (trip: Trip) => {
    setDeletingTrip(trip);
    setDeleteDialogOpen(true);
  };

  const handleSubmit = async (data: TripFormData) => {
    setSubmitting(true);
    try {
      const startDateStr = dayjs(data.startDate).format('YYYY-MM-DD');
      const endDateStr = dayjs(data.endDate).format('YYYY-MM-DD');

      if (editingTrip) {
        await updateTrip(editingTrip.id, {
          name: data.name,
          destination: data.destination,
          startDate: startDateStr,
          endDate: endDateStr,
          budgetPerPerson: data.budgetPerPerson,
        });
        toast.success('旅程已更新');
      } else {
        const newTrip = await createTrip({
          name: data.name,
          destination: data.destination,
          startDate: startDateStr,
          endDate: endDateStr,
          budgetPerPerson: data.budgetPerPerson,
        });
        toast.success('旅程创建成功');
        setCurrentTrip(newTrip.id);
      }
      setDialogOpen(false);
      setEditingTrip(null);
      await refreshTrips();
    } catch (e) {
      logger.error('保存旅程失败', e);
      toast.error('保存失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deletingTrip) return;
    setDeleting(true);
    try {
      await deleteTrip(deletingTrip.id);
      toast.success('旅程已删除');
      if (currentTripId === deletingTrip.id) {
        setCurrentTrip(null);
      }
      setDeleteDialogOpen(false);
      setDeletingTrip(null);
      await refreshTrips();
    } catch (e) {
      logger.error('删除旅程失败', e);
      toast.error('删除失败，请重试');
    } finally {
      setDeleting(false);
    }
  };

  const handleSetCurrent = (trip: Trip) => {
    setCurrentTrip(trip.id);
    toast.success(`已切换到「${trip.name}」`);
    navigate('/');
  };

  const formatDateRange = (start: string, end: string): string => {
    const s = dayjs(start);
    const e = dayjs(end);
    const days = e.diff(s, 'day') + 1;
    return `${s.format('YYYY.MM.DD')} - ${e.format('MM.DD')}（${days}天）`;
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Skeleton className="h-8 w-32" />
            <Skeleton className="h-4 w-48 mt-2" />
          </div>
          <Skeleton className="h-9 w-28" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i: number) => (
            <Skeleton key={i} className="h-48 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">旅程管理</h1>
          <p className="text-sm text-slate-500 mt-1">
            创建和管理你的毕业旅行计划，设置目的地、日期和预算
          </p>
        </div>
        <Button onClick={openCreateDialog}>
          <Plus size={18} />
          新建旅程
        </Button>
      </div>

      {trips.length === 0 ? (
        <Card className="border-dashed border-2 border-slate-200">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-100 to-pink-100 flex items-center justify-center mb-4">
              <Compass className="w-8 h-8 text-indigo-500" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">
              还没有旅程
            </h3>
            <p className="text-sm text-slate-500 mb-6 text-center max-w-sm">
              创建你的第一个毕业旅行计划，和小伙伴们一起出发吧
            </p>
            <Button onClick={openCreateDialog}>
              <Plus size={18} />
              创建第一个旅程
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
          data-ai-section-type="card-list"
        >
          {trips.map((trip: Trip) => {
            const isCurrent = currentTripId === trip.id;
            return (
              <Card
                key={trip.id}
                className={`overflow-hidden transition-all hover:shadow-md ${
                  isCurrent ? 'ring-2 ring-indigo-500 ring-offset-2' : ''
                }`}
              >
                <div className="h-2 bg-gradient-to-r from-indigo-500 to-pink-500" />
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-lg flex-1 truncate">
                      {trip.name}
                    </CardTitle>
                    {isCurrent && (
                      <Badge className="flex-shrink-0 bg-indigo-100 text-indigo-700 border-transparent">
                        <CheckCircle2 size={12} className="mr-1" />
                        当前旅程
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 text-sm text-slate-500">
                    <MapPin size={14} />
                    <span>{trip.destination}</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <CalendarDays size={14} className="text-slate-400" />
                    <span>{formatDateRange(trip.startDate, trip.endDate)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Wallet size={14} className="text-slate-400" />
                    <span>人均 ¥{trip.budgetPerPerson.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Users size={14} className="text-slate-400" />
                    <span>成员管理</span>
                  </div>
                  <div className="flex items-center gap-2 pt-2">
                    {!isCurrent && (
                      <Button
                        variant="default"
                        size="sm"
                        className="flex-1"
                        onClick={() => handleSetCurrent(trip)}
                      >
                        设为当前
                      </Button>
                    )}
                    {isCurrent && (
                      <Button
                        variant="secondary"
                        size="sm"
                        className="flex-1"
                        onClick={() => navigate('/')}
                      >
                        查看概览
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      size="icon"
                      aria-label="编辑"
                      onClick={() => openEditDialog(trip)}
                    >
                      <Pencil size={16} />
                    </Button>
                    <AlertDialog
                      open={deleteDialogOpen && deletingTrip?.id === trip.id}
                      onOpenChange={(open: boolean) => {
                        if (!open) {
                          setDeleteDialogOpen(false);
                          setDeletingTrip(null);
                        }
                      }}
                    >
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          aria-label="删除"
                          className="text-red-500 hover:text-red-600 hover:border-red-200 hover:bg-red-50"
                          onClick={() => openDeleteDialog(trip)}
                        >
                          <Trash2 size={16} />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>确认删除</AlertDialogTitle>
                          <AlertDialogDescription>
                            确定要删除旅程「{deletingTrip?.name}」吗？
                            此操作会同时删除所有相关的成员、行程、账单和待办数据，且无法恢复。
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel disabled={deleting}>
                            取消
                          </AlertDialogCancel>
                          <AlertDialogAction
                            className="bg-red-500 hover:bg-red-600 border-red-600"
                            onClick={(e) => {
                              e.preventDefault();
                              void handleDelete();
                            }}
                            disabled={deleting}
                          >
                            {deleting ? '删除中...' : '确认删除'}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <TripDialog
        trip={editingTrip ?? undefined}
        open={dialogOpen}
        onOpenChange={(open: boolean) => {
          setDialogOpen(open);
          if (!open) setEditingTrip(null);
        }}
        onSubmit={handleSubmit}
        mode={editingTrip ? 'edit' : 'create'}
      />
    </div>
  );
};

export default TripsPage;
