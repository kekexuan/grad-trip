import React, { useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import {
  CheckSquare,
  Plus,
  Trash2,
  ListTodo,
  CheckCircle,
  Circle,
  ClipboardList,
} from 'lucide-react';
import { useTripContext } from '@client/src/context/TripContext';
import {
  createTodo,
  deleteTodo,
  listTodos,
  updateTodo,
} from '@client/src/api/todos';
import type { Todo } from '@shared/api.interface';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@client/src/components/ui/card';
import { Checkbox } from '@client/src/components/ui/checkbox';
import { Input } from '@client/src/components/ui/input';
import { Badge } from '@client/src/components/ui/badge';
import { Progress } from '@client/src/components/ui/progress';
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@client/src/components/ui/empty';
import { Skeleton } from '@client/src/components/ui/skeleton';

type FilterType = 'all' | 'active' | 'completed';

const TodosPage: React.FC = () => {
  const { currentTripId, refreshCurrentTrip } = useTripContext();
  const [todos, setTodos] = useState<Todo[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [newTodo, setNewTodo] = useState<string>('');
  const [adding, setAdding] = useState<boolean>(false);
  const [filter, setFilter] = useState<FilterType>('all');
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  useEffect(() => {
    if (currentTripId) {
      void fetchTodos();
    }
  }, [currentTripId]);

  const fetchTodos = async () => {
    if (!currentTripId) return;
    try {
      setLoading(true);
      const data: Todo[] = await listTodos(currentTripId);
      setTodos(data);
    } catch (e) {
      logger.error('加载待办列表失败', e);
      toast.error('加载待办列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleAdd = async () => {
    if (!currentTripId || !newTodo.trim()) return;
    const content: string = newTodo.trim();
    try {
      setAdding(true);
      await createTodo({ tripId: currentTripId, content });
      setNewTodo('');
      void fetchTodos();
      void refreshCurrentTrip();
    } catch (e) {
      logger.error('添加待办失败', e);
      toast.error('添加待办失败');
    } finally {
      setAdding(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      void handleAdd();
    }
  };

  const handleToggle = async (todo: Todo) => {
    try {
      await updateTodo(todo.id, { completed: !todo.completed });
      setTodos((prev: Todo[]) =>
        prev.map((t: Todo) =>
          t.id === todo.id ? { ...t, completed: !t.completed } : t,
        ),
      );
      void refreshCurrentTrip();
    } catch (e) {
      logger.error('更新待办失败', e);
      toast.error('更新待办失败');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteTodo(id);
      setTodos((prev: Todo[]) => prev.filter((t: Todo) => t.id !== id));
      toast.success('待办已删除');
      void refreshCurrentTrip();
    } catch (e) {
      logger.error('删除待办失败', e);
      toast.error('删除待办失败');
    }
  };

  const total: number = todos.length;
  const completedCount: number = todos.filter((t: Todo) => t.completed).length;
  const activeCount: number = total - completedCount;
  const progress: number = total > 0 ? Math.round((completedCount / total) * 100) : 0;

  const filteredTodos: Todo[] = todos.filter((t: Todo) => {
    if (filter === 'active') return !t.completed;
    if (filter === 'completed') return t.completed;
    return true;
  });

  const filterButtons: { key: FilterType; label: string; count: number; icon: React.ReactNode }[] = [
    { key: 'all', label: '全部', count: total, icon: <ClipboardList className="h-3.5 w-3.5" /> },
    { key: 'active', label: '未完成', count: activeCount, icon: <Circle className="h-3.5 w-3.5" /> },
    { key: 'completed', label: '已完成', count: completedCount, icon: <CheckCircle className="h-3.5 w-3.5" /> },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">待办清单</h1>
        <p className="text-sm text-slate-500 mt-1">
          行前准备事项清单，确保出发前一切就绪
        </p>
      </div>

      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <CheckSquare className="h-5 w-5 text-indigo-500" />
            行前待办
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          {/* 添加区 */}
          <div className="flex gap-2">
            <Input
              placeholder="添加一条待办事项，按回车确认"
              value={newTodo}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setNewTodo(e.target.value)
              }
              onKeyDown={handleKeyDown}
              disabled={adding}
            />
            <Button
              onClick={handleAdd}
              disabled={!newTodo.trim() || adding}
            >
              <Plus className="h-4 w-4" />
              添加
            </Button>
          </div>

          {/* 统计 + 进度 */}
          {total > 0 && (
            <div className="bg-slate-50 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ListTodo className="h-4 w-4 text-indigo-500" />
                  <span className="text-sm font-medium text-slate-700">
                    完成进度
                  </span>
                </div>
                <span className="text-sm font-semibold text-indigo-600">
                  {progress}%
                </span>
              </div>
              <Progress value={progress} className="h-2" />
              <div className="flex items-center gap-3 text-sm">
                <Badge variant="secondary">共 {total} 项</Badge>
                <Badge variant="outline" className="text-emerald-600 bg-emerald-50 border-emerald-200">
                  已完成 {completedCount}
                </Badge>
                <Badge variant="outline" className="text-amber-600 bg-amber-50 border-amber-200">
                  未完成 {activeCount}
                </Badge>
              </div>
            </div>
          )}

          {/* 筛选 */}
          {total > 0 && (
            <div className="flex gap-2">
              {filterButtons.map(
                ({ key, label, count, icon }: { key: FilterType; label: string; count: number; icon: React.ReactNode }) => (
                  <Button
                    key={key}
                    variant={filter === key ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setFilter(key)}
                    className="flex items-center gap-1.5"
                  >
                    {icon}
                    {label}
                    <span className="text-xs opacity-70">({count})</span>
                  </Button>
                ),
              )}
            </div>
          )}

          {/* 列表 */}
          {loading ? (
            <div className="space-y-2">
              {[1, 2, 3, 4].map((i: number) => (
                <Skeleton key={i} className="h-12 rounded-lg" />
              ))}
            </div>
          ) : filteredTodos.length === 0 ? (
            <Empty className="border-slate-200">
              <EmptyHeader>
                <EmptyMedia variant="icon" className="bg-indigo-50 text-indigo-500">
                  {total === 0 ? (
                    <ListTodo className="h-6 w-6" />
                  ) : (
                    <CheckCircle className="h-6 w-6" />
                  )}
                </EmptyMedia>
                <EmptyTitle>
                  {total === 0
                    ? '暂无待办'
                    : filter === 'active'
                    ? '没有未完成的待办'
                    : '没有已完成的待办'}
                </EmptyTitle>
                <EmptyDescription>
                  {total === 0
                    ? '添加第一条待办事项，规划你的毕业旅行准备清单'
                    : filter === 'active'
                    ? '太棒了！所有待办都已完成 🎉'
                    : '勾选完成的事项会显示在这里'}
                </EmptyDescription>
              </EmptyHeader>
              {total === 0 && (
                <EmptyContent>
                  <Button size="sm" onClick={() => document.querySelector('input')?.focus()}>
                    <Plus className="h-4 w-4" />
                    添加待办
                  </Button>
                </EmptyContent>
              )}
            </Empty>
          ) : (
            <div className="space-y-1.5">
              {filteredTodos.map((todo: Todo) => (
                <div
                  key={todo.id}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg border transition-all group ${
                    todo.completed
                      ? 'bg-slate-50 border-slate-100'
                      : 'bg-white border-slate-200 hover:border-indigo-200 hover:shadow-sm'
                  }`}
                  onMouseEnter={() => setHoveredId(todo.id)}
                  onMouseLeave={() => setHoveredId(null)}
                >
                  <Checkbox
                    checked={todo.completed}
                    onCheckedChange={() => handleToggle(todo)}
                    id={`todo-${todo.id}`}
                  />
                  <label
                    htmlFor={`todo-${todo.id}`}
                    className={`flex-1 text-sm cursor-pointer select-none ${
                      todo.completed
                        ? 'line-through text-slate-400'
                        : 'text-slate-700'
                    }`}
                  >
                    {todo.content}
                  </label>
                  <Button
                    size="icon"
                    variant="ghost"
                    className={`h-8 w-8 transition-opacity ${
                      hoveredId === todo.id
                        ? 'opacity-100'
                        : 'opacity-0'
                    } text-slate-400 hover:text-red-500 hover:bg-red-50`}
                    onClick={() => handleDelete(todo.id)}
                    aria-label={`删除 ${todo.content}`}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default TodosPage;
