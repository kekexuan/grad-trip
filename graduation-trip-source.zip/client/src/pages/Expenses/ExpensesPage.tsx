import { useCallback, useEffect, useMemo, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import {
  Plus,
  Pencil,
  Trash2,
  Receipt,
  ArrowRight,
  Users,
  PieChart,
  Wallet,
} from 'lucide-react';

import { useTripContext } from '@client/src/context/TripContext';
import {
  createExpense,
  deleteExpense,
  getExpenseSummary,
  listExpenses,
  updateExpense,
} from '@client/src/api/expenses';
import type {
  Expense,
  ExpenseSummary,
  Member,
} from '@shared/api.interface';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@/components/ui/empty';
import { Skeleton } from '@/components/ui/skeleton';
import {
  CATEGORY_COLORS,
  CATEGORY_LABELS,
  EXPENSE_CATEGORIES,
} from '@/utils/category-config';

const formSchema = z.object({
  item: z.string().min(1, '请输入项目名称'),
  amount: z.coerce.number().min(0.01, '金额必须大于 0'),
  payerId: z.string().min(1, '请选择付款人'),
  category: z.enum([
    'transportation',
    'accommodation',
    'food',
    'attraction',
    'shopping',
    'other',
  ]),
  shareMemberIds: z.array(z.string()).min(1, '至少选择一位分摊成员'),
  note: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const ExpensesPage = () => {
  const { currentTripId, currentTrip, loading: tripLoading } = useTripContext();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [summary, setSummary] = useState<ExpenseSummary | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [submitting, setSubmitting] = useState<boolean>(false);

  const members: Member[] = useMemo(
    () => currentTrip?.members ?? [],
    [currentTrip],
  );

  const memberMap = useMemo(() => {
    const map = new Map<string, Member>();
    for (const m of members) {
      map.set(m.id, m);
    }
    return map;
  }, [members]);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema) as unknown as Parameters<
      typeof useForm<FormValues>
    >[0]['resolver'],
    defaultValues: {
      item: '',
      amount: 0,
      payerId: '',
      category: 'other',
      shareMemberIds: [],
      note: '',
    },
  });

  const fetchData = useCallback(async () => {
    if (!currentTripId) {
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      const [expensesData, summaryData] = await Promise.all([
        listExpenses(currentTripId),
        getExpenseSummary(currentTripId),
      ]);
      setExpenses(expensesData);
      setSummary(summaryData);
    } catch (e) {
      logger.error('加载账单数据失败', e);
      toast.error('加载账单数据失败');
    } finally {
      setLoading(false);
    }
  }, [currentTripId]);

  useEffect(() => {
    void fetchData();
  }, [fetchData]);

  const handleOpenCreate = () => {
    setEditingExpense(null);
    const allMemberIds = members.map((m) => m.id);
    form.reset({
      item: '',
      amount: 0,
      payerId: members[0]?.id ?? '',
      category: 'other',
      shareMemberIds: allMemberIds,
      note: '',
    });
    setDialogOpen(true);
  };

  const handleOpenEdit = (expense: Expense) => {
    setEditingExpense(expense);
    form.reset({
      item: expense.item,
      amount: expense.amount,
      payerId: expense.payerId,
      category: expense.category,
      shareMemberIds: expense.shareMemberIds ?? [],
      note: expense.note,
    });
    setDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!currentTripId) return;
    try {
      await deleteExpense(id);
      toast.success('删除成功');
      void fetchData();
    } catch (e) {
      logger.error('删除账单失败', e);
      toast.error('删除失败');
    }
  };

  const onSubmit = async (values: FormValues) => {
    if (!currentTripId) return;
    try {
      setSubmitting(true);
      if (editingExpense) {
        await updateExpense(editingExpense.id, {
          item: values.item,
          amount: values.amount,
          payerId: values.payerId,
          category: values.category,
          shareMemberIds: values.shareMemberIds,
          note: values.note ?? '',
        });
        toast.success('更新成功');
      } else {
        await createExpense({
          tripId: currentTripId,
          item: values.item,
          amount: values.amount,
          payerId: values.payerId,
          category: values.category,
          shareMemberIds: values.shareMemberIds,
          note: values.note ?? '',
        });
        toast.success('添加成功');
      }
      setDialogOpen(false);
      void fetchData();
    } catch (e) {
      logger.error('保存账单失败', e);
      toast.error('保存失败');
    } finally {
      setSubmitting(false);
    }
  };

  const toggleShareMember = (memberId: string, checked: boolean) => {
    const current = form.getValues('shareMemberIds') ?? [];
    const next = checked
      ? [...current, memberId]
      : current.filter((id: string) => id !== memberId);
    form.setValue('shareMemberIds', next, { shouldValidate: true });
  };

  const selectAllMembers = () => {
    form.setValue(
      'shareMemberIds',
      members.map((m) => m.id),
      { shouldValidate: true },
    );
  };

  // 费用构成饼图
  const pieOption = useMemo<EChartsOption>(() => {
    const data = (summary?.costByCategory ?? []).map((c) => ({
      name: c.categoryLabel,
      value: c.amount,
    }));
    const colors = (summary?.costByCategory ?? []).map(
      (c) =>
        CATEGORY_COLORS[c.category as keyof typeof CATEGORY_COLORS] ?? '#64748b',
    );
    return {
      tooltip: {
        trigger: 'item',
        formatter: (params) => {
          if (Array.isArray(params)) return '';
          return `${params.name}<br/>金额：¥${Number(params.value).toFixed(2)}`;
        },
      },
      legend: {
        type: 'scroll',
        bottom: 0,
      },
      color: colors.length > 0 ? colors : ['#6366f1'],
      series: [
        {
          type: 'pie',
          radius: ['45%', '70%'],
          center: ['50%', '45%'],
          avoidLabelOverlap: false,
          label: { show: false },
          emphasis: { label: { show: false } },
          data,
        },
      ],
    };
  }, [summary]);

  // 成员收支对比柱状图（横向）
  const barOption = useMemo<EChartsOption>(() => {
    const balances = summary?.memberBalances ?? [];
    const names = balances.map((b) => b.memberName);
    const paidData = balances.map((b) => b.paid);
    const shouldPayData = balances.map((b) => b.shouldPay);
    return {
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        formatter: (params) => {
          const list = Array.isArray(params) ? params : [params];
          const title = list[0]?.name ?? '';
          const lines = list.map(
            (p) =>
              `${p.marker}${p.seriesName}：¥${Number(p.value).toFixed(2)}`,
          );
          return `${title}<br/>${lines.join('<br/>')}`;
        },
      },
      legend: {
        bottom: 0,
        data: ['已付', '应摊'],
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '15%',
        top: '5%',
        containLabel: true,
      },
      xAxis: {
        type: 'value',
        axisLabel: {
          formatter: (value: number | string) => `¥${value}`,
        },
      },
      yAxis: {
        type: 'category',
        data: names,
      },
      series: [
        {
          name: '已付',
          type: 'bar',
          data: paidData,
          itemStyle: { color: '#10b981' },
          barWidth: 16,
        },
        {
          name: '应摊',
          type: 'bar',
          data: shouldPayData,
          itemStyle: { color: '#f59e0b' },
          barWidth: 16,
        },
      ],
    };
  }, [summary]);

  if (tripLoading && !currentTrip) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!currentTripId || !currentTrip) {
    return (
      <div className="p-6">
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Wallet className="size-6" />
            </EmptyMedia>
            <EmptyTitle>暂无旅程</EmptyTitle>
            <EmptyDescription>请先创建或选择一个旅程</EmptyDescription>
          </EmptyHeader>
        </Empty>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6" data-ai-section-type="card-list">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">账单分摊</h1>
          <p className="mt-1 text-sm text-slate-500">
            记录旅行中的每一笔支出，自动计算人均分摊和结算方案
          </p>
        </div>
        <Button onClick={handleOpenCreate} data-ai-section-type="button">
          <Plus className="size-4" />
          记一笔
        </Button>
      </div>

      {/* 支出列表区 */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-lg font-semibold">
            <span className="flex items-center gap-2">
              <Receipt className="size-5 text-primary" />
              支出记录
            </span>
          </CardTitle>
          <div className="text-right">
            <p className="text-xs text-slate-500">总支出</p>
            <p className="text-xl font-bold text-primary">
              ¥{summary?.totalAmount?.toFixed(2) ?? '0.00'}
            </p>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          ) : expenses.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <Receipt className="size-6" />
                </EmptyMedia>
                <EmptyTitle>暂无支出记录</EmptyTitle>
                <EmptyDescription>
                  点击右上角「记一笔」开始记账吧
                </EmptyDescription>
              </EmptyHeader>
            </Empty>
          ) : (
            <div className="space-y-3">
              {expenses.map((expense) => {
                const payer = memberMap.get(expense.payerId);
                const shareCount = expense.shareMemberIds?.length ?? 0;
                return (
                  <Card
                    key={expense.id}
                    className="transition-shadow hover:shadow-md"
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex min-w-0 items-center gap-4">
                          <div
                            className="flex size-12 shrink-0 items-center justify-center rounded-lg text-white"
                            style={{
                              backgroundColor:
                                CATEGORY_COLORS[expense.category] ?? '#64748b',
                            }}
                          >
                            <span className="text-xs font-medium">
                              {CATEGORY_LABELS[expense.category]}
                            </span>
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <h3 className="truncate text-base font-semibold text-slate-800">
                                {expense.item}
                              </h3>
                              <Badge
                                variant="secondary"
                                className="shrink-0 text-xs"
                              >
                                {CATEGORY_LABELS[expense.category]}
                              </Badge>
                            </div>
                            <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                              <span className="flex items-center gap-1">
                                <Users className="size-3" />
                                付款人：{payer?.name ?? '未知'}
                              </span>
                              <span>{shareCount} 人分摊</span>
                              {expense.note && (
                                <span className="truncate">
                                  备注：{expense.note}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <p className="text-xl font-bold text-slate-800">
                              ¥{expense.amount.toFixed(2)}
                            </p>
                            {shareCount > 0 && (
                              <p className="text-xs text-slate-500">
                                人均 ¥
                                {(expense.amount / shareCount).toFixed(2)}
                              </p>
                            )}
                          </div>
                          <div className="flex shrink-0 gap-1">
                            <Button
                              size="icon"
                              variant="ghost"
                              className="size-8"
                              aria-label="编辑支出"
                              onClick={() => handleOpenEdit(expense)}
                            >
                              <Pencil className="size-4" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="size-8 text-red-500 hover:text-red-600"
                              aria-label="删除支出"
                              onClick={() => handleDelete(expense.id)}
                            >
                              <Trash2 className="size-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* 费用构成饼图 */}
      {summary && summary.costByCategory.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base font-semibold">
              <PieChart className="size-5 text-primary" />
              费用构成
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ReactECharts
              option={pieOption}
              theme="ud"
              className="h-[300px] w-full"
            />
          </CardContent>
        </Card>
      )}

      {/* 结算分析区 */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold">账单分析</CardTitle>
        </CardHeader>
        <CardContent>
          {loading || !summary ? (
            <div className="grid gap-6 md:grid-cols-2">
              <Skeleton className="h-[300px] w-full" />
              <Skeleton className="h-[300px] w-full" />
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2">
              {/* 左栏：成员收支对比 */}
              <div>
                <h3 className="mb-3 text-sm font-semibold text-slate-700">
                  成员收支对比
                </h3>
                {summary.memberBalances.length === 0 ? (
                  <Empty className="py-12">
                    <EmptyHeader>
                      <EmptyTitle className="text-sm">暂无数据</EmptyTitle>
                    </EmptyHeader>
                  </Empty>
                ) : (
                  <ReactECharts
                    option={barOption}
                    theme="ud"
                    className="h-[300px] w-full"
                  />
                )}
              </div>

              {/* 右栏：结算方案 */}
              <div>
                <h3 className="mb-3 text-sm font-semibold text-slate-700">
                  结算方案：谁该转给谁
                </h3>
                {summary.settlementPlan.length === 0 ? (
                  <Empty className="py-12">
                    <EmptyHeader>
                      <EmptyMedia variant="icon">
                        <Users className="size-5" />
                      </EmptyMedia>
                      <EmptyTitle className="text-sm">
                        大家已经两清啦~
                      </EmptyTitle>
                      <EmptyDescription>
                        还没有需要结算的转账
                      </EmptyDescription>
                    </EmptyHeader>
                  </Empty>
                ) : (
                  <div className="space-y-3">
                    {summary.settlementPlan.map((transfer, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between rounded-xl bg-gradient-to-r from-indigo-50 to-pink-50 p-4"
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex size-10 items-center justify-center rounded-full bg-white text-sm font-semibold text-slate-700 shadow-sm">
                            {transfer.fromMemberName?.charAt(0) ?? '?'}
                          </div>
                          <div>
                            <p className="text-sm font-medium text-slate-700">
                              {transfer.fromMemberName}
                            </p>
                            <p className="text-xs text-slate-500">付款人</p>
                          </div>
                        </div>
                        <ArrowRight className="size-5 text-primary" />
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <p className="text-sm font-medium text-slate-700">
                              {transfer.toMemberName}
                            </p>
                            <p className="text-xs text-slate-500">收款人</p>
                          </div>
                          <div className="flex size-10 items-center justify-center rounded-full bg-white text-sm font-semibold text-slate-700 shadow-sm">
                            {transfer.toMemberName?.charAt(0) ?? '?'}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-primary">
                            ¥{transfer.amount.toFixed(2)}
                          </p>
                        </div>
                      </div>
                    ))}
                    <p className="pt-2 text-center text-xs text-slate-400">
                      转账完成后大家就两清啦~
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 添加/编辑支出弹窗 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingExpense ? '编辑支出' : '记一笔'}
            </DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(
                onSubmit as SubmitHandler<FormValues>,
              )}
              className="space-y-4"
            >
              <FormField
                control={form.control}
                name="item"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>项目名称</FormLabel>
                    <FormControl>
                      <Input placeholder="如：打车、午餐、门票" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>金额 (¥)</FormLabel>
                      <FormControl>
                        <Input type="number" min={0} step="0.01" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>类别</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="选择类别" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {EXPENSE_CATEGORIES.map((cat) => (
                            <SelectItem key={cat} value={cat}>
                              {CATEGORY_LABELS[cat]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="payerId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>付款人</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="选择付款人" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {members.map((member) => (
                          <SelectItem key={member.id} value={member.id}>
                            {member.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="shareMemberIds"
                render={() => (
                  <FormItem>
                    <div className="flex items-center justify-between">
                      <FormLabel>分摊成员</FormLabel>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="h-auto px-2 py-1 text-xs"
                        onClick={selectAllMembers}
                      >
                        全选
                      </Button>
                    </div>
                    <FormControl>
                      <div className="grid grid-cols-2 gap-2 rounded-md border border-slate-200 p-3">
                        {members.map((member) => {
                          const checked = (
                            form.watch('shareMemberIds') ?? []
                          ).includes(member.id);
                          return (
                            <label
                              key={member.id}
                              className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm transition-colors hover:bg-slate-50"
                            >
                              <Checkbox
                                checked={checked}
                                onCheckedChange={(val) =>
                                  toggleShareMember(member.id, Boolean(val))
                                }
                              />
                              <span className="text-slate-700">
                                {member.name}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="note"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>备注</FormLabel>
                    <FormControl>
                      <Textarea rows={2} placeholder="可选" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                >
                  取消
                </Button>
                <Button type="submit" disabled={submitting}>
                  {submitting ? '保存中...' : editingExpense ? '保存修改' : '添加'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ExpensesPage;
