import type { ExpenseCategory, ItineraryCategory } from '@shared/api.interface';

export const CATEGORY_LABELS: Record<ExpenseCategory, string> = {
  transportation: '交通',
  accommodation: '住宿',
  food: '餐饮',
  attraction: '景点',
  shopping: '购物',
  other: '其他',
};

export const CATEGORY_COLORS: Record<ExpenseCategory, string> = {
  transportation: '#6366f1',
  accommodation: '#ec4899',
  food: '#f59e0b',
  attraction: '#10b981',
  shopping: '#8b5cf6',
  other: '#64748b',
};

export const CATEGORY_BADGE_VARIANT: Record<
  ExpenseCategory,
  'default' | 'secondary' | 'destructive' | 'outline'
> = {
  transportation: 'default',
  accommodation: 'secondary',
  food: 'secondary',
  attraction: 'default',
  shopping: 'secondary',
  other: 'outline',
};

export const ITINERARY_CATEGORIES: ItineraryCategory[] = [
  'transportation',
  'accommodation',
  'food',
  'attraction',
  'shopping',
  'other',
];

export const EXPENSE_CATEGORIES: ExpenseCategory[] = [
  'transportation',
  'accommodation',
  'food',
  'attraction',
  'shopping',
  'other',
];
