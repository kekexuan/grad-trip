export type BudgetTier = 'economy' | 'standard' | 'premium';

export type ExpenseCategory =
  | 'transportation'
  | 'accommodation'
  | 'food'
  | 'attraction'
  | 'shopping'
  | 'other';

export type ItineraryCategory =
  | 'transportation'
  | 'accommodation'
  | 'food'
  | 'attraction'
  | 'shopping'
  | 'other';

export interface Trip {
  id: string;
  name: string;
  destination: string;
  startDate: string;
  endDate: string;
  budgetPerPerson: number;
}

export interface Member {
  id: string;
  tripId: string;
  name: string;
  destinationPreference: string;
  budgetTier: BudgetTier;
  notes: string;
}

export interface ItineraryItem {
  id: string;
  tripId: string;
  dayIndex: number;
  timeSlot: string;
  content: string;
  estimatedCost: number;
  category: ItineraryCategory;
  notes: string;
}

export interface Expense {
  id: string;
  tripId: string;
  item: string;
  amount: number;
  payerId: string;
  category: ExpenseCategory;
  note: string;
  shareMemberIds: string[];
}

export interface ExpenseShare {
  id: string;
  expenseId: string;
  memberId: string;
  amount: number;
}

export interface Todo {
  id: string;
  tripId: string;
  content: string;
  completed: boolean;
}

export interface Group {
  id: string;
  tripId: string;
  groupName: string;
  memberIds: string[];
}

export interface MemberBalance {
  memberId: string;
  memberName: string;
  paid: number;
  shouldPay: number;
  netBalance: number;
}

export interface SettlementTransfer {
  fromMemberId: string;
  fromMemberName: string;
  toMemberId: string;
  toMemberName: string;
  amount: number;
}

export interface GroupSuggestion {
  id: string;
  groupName: string;
  memberIds: string[];
  memberNames: string[];
  avgBudget: number;
}

export interface TripDetail extends Trip {
  members: Member[];
  itineraryItems: ItineraryItem[];
  expenses: Expense[];
  todos: Todo[];
  groups: Group[];
}

export interface CategoryCost {
  category: string;
  categoryLabel: string;
  amount: number;
}

export interface ItinerarySummary {
  totalCost: number;
  costByCategory: CategoryCost[];
  dayCount: number;
  itemCount: number;
}

export interface ExpenseSummary {
  totalAmount: number;
  costByCategory: CategoryCost[];
  memberBalances: MemberBalance[];
  settlementPlan: SettlementTransfer[];
}

// --- Request types ---

export interface CreateTripRequest {
  name: string;
  destination: string;
  startDate: string;
  endDate: string;
  budgetPerPerson: number;
}

export interface UpdateTripRequest {
  name?: string;
  destination?: string;
  startDate?: string;
  endDate?: string;
  budgetPerPerson?: number;
}

export interface CreateMemberRequest {
  tripId: string;
  name: string;
  destinationPreference: string;
  budgetTier: BudgetTier;
  notes: string;
}

export interface UpdateMemberRequest {
  name?: string;
  destinationPreference?: string;
  budgetTier?: BudgetTier;
  notes?: string;
}

export interface CreateItineraryItemRequest {
  tripId: string;
  dayIndex: number;
  timeSlot: string;
  content: string;
  estimatedCost: number;
  category: ItineraryCategory;
  notes: string;
}

export interface UpdateItineraryItemRequest {
  dayIndex?: number;
  timeSlot?: string;
  content?: string;
  estimatedCost?: number;
  category?: ItineraryCategory;
  notes?: string;
}

export interface CreateExpenseRequest {
  tripId: string;
  item: string;
  amount: number;
  payerId: string;
  category: ExpenseCategory;
  note: string;
  shareMemberIds: string[];
}

export interface UpdateExpenseRequest {
  item?: string;
  amount?: number;
  payerId?: string;
  category?: ExpenseCategory;
  note?: string;
  shareMemberIds?: string[];
}

export interface CreateTodoRequest {
  tripId: string;
  content: string;
}

export interface UpdateTodoRequest {
  content?: string;
  completed?: boolean;
}

export interface CreateGroupsRequest {
  tripId: string;
  groups: Array<{ groupName: string; memberIds: string[] }>;
}

export interface SmartGroupRequest {
  tripId: string;
  groupCount: number;
}

export interface ExportArchive {
  trip: Trip;
  members: Member[];
  itineraryItems: ItineraryItem[];
  expenses: Expense[];
  todos: Todo[];
  groups: Group[];
  version: string;
}

export interface ImportResult {
  tripId: string;
  membersCount: number;
  itineraryItemsCount: number;
  expensesCount: number;
  todosCount: number;
  groupsCount: number;
}
